import React, { useState } from 'react';
import { UserRole, UserProfile } from '../types';
import { DEMO_PROFILES } from '../data';

interface LoginViewProps {
  onLoginSuccess: (profile: UserProfile) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLoginSuccess }) => {
  const [rut, setRut] = useState('18.987.654-3');
  const [password, setPassword] = useState('••••••••');
  const [errorMsg, setErrorMsg] = useState('');

  // Handle manual login click
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rut.trim()) {
      setErrorMsg('Por favor ingrese su RUT');
      return;
    }
    
    // Match to one of the mock roles or fallback to Conductor
    const cleanRut = rut.replace(/\./g, '').trim();
    if (cleanRut.startsWith('12')) {
      onLoginSuccess(DEMO_PROFILES.guardia);
    } else if (cleanRut.startsWith('15')) {
      onLoginSuccess(DEMO_PROFILES.directivo);
    } else {
      onLoginSuccess(DEMO_PROFILES.conductor);
    }
  };

  const handleQuickLogin = (role: UserRole) => {
    const profile = DEMO_PROFILES[role];
    setRut(profile.rut);
    onLoginSuccess(profile);
  };

  return (
    <div className="relative min-h-screen flex flex-col justify-center items-center font-sans bg-slate-50 select-none">
      {/* Background Technical Grid Texture */}
      <div 
        className="fixed inset-0 pointer-events-none opacity-40" 
        style={{
          backgroundImage: `
            linear-gradient(to right, #e2e8f0 1px, transparent 1px),
            linear-gradient(to bottom, #e2e8f0 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
          maskImage: 'radial-gradient(circle at center, black, transparent 90%)',
          WebkitMaskImage: 'radial-gradient(circle at center, black, transparent 100%)'
        }}
      ></div>

      <main className="relative z-10 w-full max-w-md px-6 py-12 flex flex-col items-center">
        {/* Branding Section */}
        <div className="flex flex-col items-center mb-6 space-y-1">
          <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center mb-2 border border-slate-200 shadow-sm">
            <span className="material-symbols-outlined text-[48px] text-[#004481]" style={{ fontVariationSettings: "'FILL' 0, 'wght' 400" }}>
              local_parking
            </span>
          </div>
          <h1 className="font-hanken text-4xl font-extrabold text-[#004481] tracking-tight">Maipú</h1>
          <p className="font-mono text-[10px] text-slate-500 uppercase tracking-widest font-semibold">
            Control de Acceso Industrial
          </p>
        </div>

        {/* Form Card */}
        <div className="w-full bg-white border border-slate-200 rounded-xl p-6 shadow-xl relative overflow-hidden">
          {/* Institutional Accent Line */}
          <div className="absolute top-0 left-0 w-full h-[6px] bg-[#004481]"></div>
          
          <form className="space-y-4 mt-2" onSubmit={handleLoginSubmit}>
            {/* RUT Input */}
            <div className="space-y-1">
              <label className="font-sans text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                RUT Usuario
              </label>
              <div className="relative flex items-center group">
                <span className="material-symbols-outlined absolute left-3.5 text-slate-400 group-focus-within:text-[#004481] transition-colors">
                  badge
                </span>
                <input 
                  className="w-full bg-slate-50 border border-slate-200 focus:border-[#004481] focus:ring-2 focus:ring-[#004481]/15 text-slate-800 font-mono text-sm pl-11 pr-4 py-3 rounded-lg outline-none transition-all placeholder:text-slate-400" 
                  placeholder="12.345.678-9" 
                  type="text"
                  value={rut}
                  onChange={(e) => setRut(e.target.value)}
                />
              </div>
            </div>

            {/* Password Input */}
            <div className="space-y-1">
              <label className="font-sans text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                Contraseña
              </label>
              <div className="relative flex items-center group">
                <span className="material-symbols-outlined absolute left-3.5 text-slate-400 group-focus-within:text-[#004481] transition-colors">
                  lock
                </span>
                <input 
                  className="w-full bg-slate-50 border border-slate-200 focus:border-[#004481] focus:ring-2 focus:ring-[#004481]/15 text-slate-800 font-mono text-sm pl-11 pr-4 py-3 rounded-lg outline-none transition-all placeholder:text-slate-400" 
                  placeholder="••••••••" 
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            {errorMsg && (
              <p className="text-red-600 text-xs text-center font-medium">{errorMsg}</p>
            )}

            {/* Action Button */}
            <button 
              className="w-full bg-[#004481] hover:bg-[#003362] text-white font-semibold text-lg py-3 rounded-lg active:scale-[0.98] transition-all flex items-center justify-center gap-2 mt-6 cursor-pointer shadow-md hover:shadow-lg"
              type="submit"
            >
              <span>Ingresar</span>
              <span className="material-symbols-outlined">login</span>
            </button>

            {/* Helper Links */}
            <div className="flex justify-between items-center pt-2 text-xs">
              <a className="text-[#004481] font-medium hover:underline transition-colors animate-fade-in" href="#forgot">
                ¿Olvidó su contraseña?
              </a>
              <div className="flex items-center gap-1.5 px-2 py-1 bg-green-50 rounded-full border border-green-200">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                <span className="text-[10px] text-green-700 font-extrabold uppercase">Sistema Online</span>
              </div>
            </div>
          </form>
        </div>

        {/* Demo Fast Access helper */}
        <div className="w-full mt-6 bg-amber-50 rounded-lg p-4 border border-amber-200 text-center animate-zoom-in">
          <p className="text-xs text-amber-800 font-semibold mb-2">Ingreso Rápido Demo (Evaluador AI Studio):</p>
          <div className="grid grid-cols-3 gap-2">
            <button 
              onClick={() => handleQuickLogin('conductor')} 
              className="px-2 py-1.5 bg-white border border-amber-300 rounded text-[11px] text-amber-900 font-bold hover:bg-amber-100 transition-colors shadow-sm cursor-pointer"
            >
              👤 Conductor
            </button>
            <button 
              onClick={() => handleQuickLogin('guardia')} 
              className="px-2 py-1.5 bg-white border border-amber-300 rounded text-[11px] text-amber-900 font-bold hover:bg-amber-100 transition-colors shadow-sm cursor-pointer"
            >
              👮 Guardia
            </button>
            <button 
              onClick={() => handleQuickLogin('directivo')} 
              className="px-2 py-1.5 bg-white border border-amber-300 rounded text-[11px] text-amber-900 font-bold hover:bg-amber-100 transition-colors shadow-sm cursor-pointer"
            >
              📊 Directivo
            </button>
          </div>
        </div>

        {/* Footer / Legal */}
        <footer className="mt-8 text-center space-y-2 w-full">
          <p className="font-mono text-[11px] text-slate-500 uppercase tracking-[0.2em] font-semibold">
            Duoc UC Sede Maipú
          </p>
          <div className="flex justify-center items-center gap-2">
            <div className="h-px w-8 bg-slate-300"></div>
            <span className="material-symbols-outlined text-slate-400 text-lg">security</span>
            <div className="h-px w-8 bg-slate-300"></div>
          </div>
          <div className="flex justify-center gap-4 pt-1">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-green-500"></span>
              <span className="text-[10px] font-extrabold text-slate-500 uppercase">Libre</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#004481]"></span>
              <span className="text-[10px] font-extrabold text-slate-500 uppercase">Ocupado</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600"></span>
              <span className="text-[10px] font-extrabold text-slate-500 uppercase">Infracción</span>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
};
