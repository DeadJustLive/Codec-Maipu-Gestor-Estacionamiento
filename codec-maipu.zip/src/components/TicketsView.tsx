import React, { useState } from 'react';
import { SupportTicket, TicketState, TicketType } from '../types';
import { generateSupportReply } from '../data';

interface TicketsViewProps {
  slots: any;
  logs: any;
  tickets: SupportTicket[];
  onUpdateState: (slots: any, logs: any, tickets: SupportTicket[]) => void;
  currentUser: { nombre: string; role: string; avatar: string };
}

export const TicketsView: React.FC<TicketsViewProps> = ({
  slots,
  logs,
  tickets,
  onUpdateState,
  currentUser
}) => {
  const [activeTab, setActiveTab] = useState<TicketState>('abierto');
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [showCreateTicketModal, setShowCreateTicketModal] = useState(false);
  
  // New ticket form states
  const [newTicketType, setNewTicketType] = useState<TicketType>('problema');
  const [newTicketMsg, setNewTicketMsg] = useState('');

  // Tab counters & filters
  const filteredTickets = tickets.filter(t => t.estado === activeTab);

  const getBorderColor = (type: TicketType) => {
    switch (type) {
      case 'problema': return 'border-l-[6px] border-red-600';
      case 'consulta': return 'border-l-[6px] border-blue-600';
      case 'reporte': return 'border-l-[6px] border-amber-600';
    }
  };

  const badgeConfig = {
    problema: { text: 'text-red-700', bg: 'bg-red-50 border border-red-200', icon: 'error' },
    consulta: { text: 'text-blue-700', bg: 'bg-blue-50 border border-blue-200', icon: 'help_center' },
    reporte: { text: 'text-amber-700', bg: 'bg-amber-50 border border-amber-200', icon: 'warning' }
  };

  // Reply submission
  const handleSendReply = (ticketId: string, text: string, isAi = false) => {
    if (!text.trim()) return;

    const updatedTickets = tickets.map((t) => {
      if (t.id === ticketId) {
        const newReply = {
          id: `rep-${Date.now()}`,
          autor: isAi ? 'Asistente AI Guardia' : currentUser.nombre,
          contenido: text,
          fecha: 'Ahora mismo'
        };

        return {
          ...t,
          estado: 'en_curso' as TicketState, // transition state
          respuestas: [...t.respuestas, newReply]
        };
      }
      return t;
    });

    onUpdateState(slots, logs, updatedTickets);
    setReplyText('');
  };

  // Trigger automated AI answer
  const handleAiAutoReply = (ticket: SupportTicket) => {
    // Generate matched institutional reply helper based on data.ts rules
    const aiAnswer = generateSupportReply(ticket);
    handleSendReply(ticket.id, aiAnswer, true);
  };

  // Close ticket
  const handleCloseTicket = (ticketId: string) => {
    const updatedTickets = tickets.map((t) => {
      if (t.id === ticketId) {
        return {
          ...t,
          estado: 'cerrado' as TicketState
        };
      }
      return t;
    });
    onUpdateState(slots, logs, updatedTickets);
    setSelectedTicketId(null);
  };

  // Create new ticket manually (Conductor View simulation)
  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTicketMsg.trim()) return;

    const newTick: SupportTicket = {
      id: `t-${Date.now()}`,
      usuarioNombre: currentUser.nombre,
      usuarioRut: currentUser.role === 'conductor' ? '18.987.654-3' : '15.000.123-K',
      tipo: newTicketType,
      estado: 'abierto',
      mensaje: newTicketMsg,
      haceTiempo: 'Hace 1 min',
      created_at: new Date().toISOString(),
      respuestas: []
    };

    onUpdateState(slots, logs, [newTick, ...tickets]);
    setNewTicketMsg('');
    setShowCreateTicketModal(false);
  };

  const selectedTicket = tickets.find(t => t.id === selectedTicketId);

  return (
    <div className="relative font-sans text-slate-800 pb-24">
      
      {/* Tab Filter System */}
      <nav className="bg-white border-b border-slate-200 flex w-full sticky top-0 z-20 shadow-sm">
        {(['abierto', 'en_curso', 'cerrado'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => {
              setActiveTab(tab);
              setSelectedTicketId(null);
            }}
            className={`flex-1 py-4 text-xs font-bold uppercase tracking-wider text-center cursor-pointer transition-all relative ${activeTab === tab ? 'text-[#004481]' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            {tab === 'abierto' ? 'Abiertos' : (tab === 'en_curso' ? 'En Curso' : 'Cerrados')}
            {activeTab === tab && (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#004481]"></div>
            )}
          </button>
        ))}
      </nav>

      {/* Main Container */}
      <main className="p-6 space-y-4">
        
        {selectedTicket ? (
          /* CONVERSATION VIEW */
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-md animate-zoom-in">
            <div className="flex justify-between items-start border-b border-slate-100 pb-3">
              <button 
                onClick={() => setSelectedTicketId(null)}
                className="flex items-center gap-1 text-[#004481] text-xs font-bold hover:underline cursor-pointer"
              >
                <span className="material-symbols-outlined text-sm">arrow_back</span>
                <span>Volver de Bandeja</span>
              </button>
              
              <div className="flex items-center gap-2">
                {selectedTicket.estado !== 'cerrado' && (
                  <button 
                    onClick={() => handleCloseTicket(selectedTicket.id)}
                    className="px-3 py-1 bg-red-50 hover:bg-red-100 text-red-700 text-[10px] font-bold rounded border border-red-200 uppercase tracking-wider cursor-pointer"
                  >
                    Cerrar Caso
                  </button>
                )}
                <span className="text-slate-400 font-mono text-[10px] font-bold">{selectedTicket.haceTiempo}</span>
              </div>
            </div>

            {/* Ticket Subject details */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/85">
              <div className="flex items-center gap-2 mb-2">
                <span className="material-symbols-outlined text-slate-500">person</span>
                <span className="font-sans text-sm font-bold text-slate-800">{selectedTicket.usuarioNombre}</span>
                <span className="text-[10px] bg-slate-200 text-slate-600 px-1.5 rounded font-mono font-semibold">RUT {selectedTicket.usuarioRut}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${badgeConfig[selectedTicket.tipo].text} ${badgeConfig[selectedTicket.tipo].bg}`}>
                  {selectedTicket.tipo}
                </span>
              </div>
              <p className="text-slate-700 text-sm italic font-medium mt-2">
                "{selectedTicket.mensaje}"
              </p>
            </div>

            {/* Message Thread */}
            <div className="space-y-4 max-h-[300px] overflow-y-auto w-full pr-1">
              <p className="text-[10px] uppercase font-mono font-bold text-slate-400">Canal de Respuestas:</p>
              
              {selectedTicket.respuestas.length === 0 ? (
                <p className="text-slate-400 text-xs italic text-center py-4">No hay respuestas en este ticket. ¡Escriba un mensaje de apoyo abajo o use el Asistente AI!</p>
              ) : (
                selectedTicket.respuestas.map((resp) => {
                  const isAi = resp.autor.toLowerCase().includes('ai') || resp.autor.toLowerCase().includes('asistente');
                  return (
                    <div 
                      key={resp.id}
                      className={`p-3.5 rounded-xl border max-w-[85%] ${isAi ? 'bg-amber-50 border-amber-200 ml-auto animate-slide-in' : 'bg-slate-50 border-slate-200 mr-auto animate-slide-in'}`}
                    >
                      <div className="flex justify-between items-center mb-1 gap-4">
                        <span className={`text-[10px] font-bold uppercase tracking-wider ${isAi ? 'text-amber-800' : 'text-[#004481]'}`}>
                          {resp.autor}
                        </span>
                        <span className="text-[9px] text-slate-400 font-mono font-bold">{resp.fecha}</span>
                      </div>
                      <p className="text-xs text-slate-700 font-medium">{resp.contenido}</p>
                    </div>
                  );
                })
              )}
            </div>

            {/* Input Form Controls */}
            {selectedTicket.estado !== 'cerrado' && (
              <div className="pt-4 border-t border-slate-100 flex flex-col gap-2">
                <input 
                  type="text"
                  placeholder="Escribir mensaje de asistencia para el conductor..."
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-sm focus:border-[#004481] outline-none"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSendReply(selectedTicket.id, replyText);
                  }}
                />
                
                <div className="flex justify-between items-center">
                  <button
                    onClick={() => handleAiAutoReply(selectedTicket)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-amber-50 border border-amber-300 rounded-lg text-xs font-bold text-amber-850 hover:bg-amber-100 cursor-pointer transition-all active:scale-95 animate-fade-in"
                  >
                    <span className="material-symbols-outlined text-sm">smart_toy</span>
                    <span>Responder con AI Guardia</span>
                  </button>
                  
                  <button 
                    onClick={() => handleSendReply(selectedTicket.id, replyText)}
                    className="px-5 py-2 bg-[#004481] hover:bg-[#003362] text-white rounded-lg text-xs font-bold cursor-pointer transition-colors shadow-sm"
                  >
                    Enviar Respuesta
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* TICKETS FEED FEED */
          <div className="space-y-4">
            
            {filteredTickets.map((ticket) => {
              const badge = badgeConfig[ticket.tipo];
              
              return (
                <div 
                  key={ticket.id}
                  className={`ticket-card bg-white p-5 rounded-2xl ${getBorderColor(ticket.tipo)} flex flex-col gap-3 shadow-xs border border-slate-200 transition-all hover:translate-x-1`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-1.5">
                      <span className={`material-symbols-outlined text-sm ${badge.text}`}>
                        {badge.icon}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${badge.bg}`}>
                        {ticket.tipo}
                      </span>
                    </div>
                    <span className="text-slate-400 font-mono text-xs font-semibold">{ticket.haceTiempo}</span>
                  </div>

                  <div>
                    <h3 className="font-hanken text-lg font-extrabold text-[#1c1b1b]">{ticket.usuarioNombre}</h3>
                    <p className="font-mono text-xs text-slate-400 font-bold">RUT: {ticket.usuarioRut}</p>
                  </div>

                  <p className="text-slate-600 text-xs italic font-medium line-clamp-2">
                    "{ticket.mensaje}"
                  </p>

                  <div className="flex justify-end gap-2 mt-2 pt-2 border-t border-slate-100">
                    <button 
                      onClick={() => handleAiAutoReply(ticket)}
                      className="px-3 py-1.5 border border-amber-300 text-amber-850 bg-amber-50 rounded-lg text-xs font-bold hover:bg-amber-100 cursor-pointer active:scale-95 transition-all flex items-center gap-1"
                    >
                      <span className="material-symbols-outlined text-sm">smart_toy</span>
                      <span>AI Responder</span>
                    </button>
                    
                    <button 
                      onClick={() => setSelectedTicketId(ticket.id)}
                      className="px-4 py-1.5 bg-[#004481] text-white hover:bg-[#003362] transition-colors rounded-lg font-bold text-xs shadow-sm cursor-pointer"
                    >
                      Ver Detalle / Responder
                    </button>
                  </div>
                </div>
              );
            })}

            {filteredTickets.length === 0 && (
              <div className="py-12 bg-white rounded-xl border border-dashed border-slate-200 text-center">
                <span className="material-symbols-outlined text-slate-300 text-6xl">check_box</span>
                <p className="text-slate-500 font-bold text-sm mt-3">¡Excelente! Cero tickets en este estado</p>
                <p className="text-slate-400 text-xs mt-1">Todos los incidentes han sido coordinados con éxito.</p>
              </div>
            )}

          </div>
        )}
      </main>

      {/* Quick floating create ticket action */}
      <button 
        onClick={() => setShowCreateTicketModal(true)}
        className="fixed bottom-20 right-6 w-14 h-14 bg-[#004481] hover:bg-[#003362] text-white rounded-full shadow-lg flex items-center justify-center hover:scale-105 active:scale-95 transition-transform z-40 border-4 border-white cursor-pointer"
      >
        <span className="material-symbols-outlined font-extrabold">search</span>
      </button>

      {/* CREATE TICKET MODAL (Mainly for simulated Driver workflow) */}
      {showCreateTicketModal && (
        <div className="fixed inset-0 bg-slate-900/80 z-50 flex h-full items-center justify-center p-6 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 relative shadow-2xl border border-slate-200 animate-zoom-in">
            <button 
              onClick={() => setShowCreateTicketModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <span className="material-symbols-outlined text-2xl">close</span>
            </button>

            <h3 className="font-hanken text-lg font-extrabold text-slate-900 mb-1">
              Abrir Ticket Técnico Sede Maipú
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Consulte a soporte sobre barreras de acceso, reportes o averías.
            </p>

            <form onSubmit={handleCreateTicket} className="space-y-4">
              <div>
                <label className="text-xs font-extrabold text-slate-700 block mb-1">Categoría del Ticket</label>
                <select 
                  value={newTicketType}
                  onChange={(e) => setNewTicketType(e.target.value as TicketType)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#004481] focus:ring-1 focus:ring-[#004481]/20 font-medium"
                >
                  <option value="problema">Problema de validación QR / Barrera</option>
                  <option value="consulta">Consulta de cupos / PMR discapacitados</option>
                  <option value="reporte">Reportar vehículo bloqueador u obstructor</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-extrabold text-slate-700 block mb-1">Escriba su mensaje</label>
                <textarea
                  value={newTicketMsg}
                  onChange={(e) => setNewTicketMsg(e.target.value)}
                  placeholder="Describa brevemente el caso..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none h-28 resize-none focus:border-[#004481] focus:ring-1 focus:ring-[#004481]/20"
                  required
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateTicketModal(false)}
                  className="w-1/2 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-xs font-bold cursor-pointer transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2 bg-[#004481] hover:bg-[#003362] text-white rounded-lg text-xs font-bold shadow-sm cursor-pointer transition-colors"
                >
                  Crear Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
