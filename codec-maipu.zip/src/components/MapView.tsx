import React, { useState } from 'react';
import { ParkingSlot, ActivityLog, SupportTicket } from '../types';

interface MapViewProps {
  slots: ParkingSlot[];
  logs: ActivityLog[];
  tickets: SupportTicket[];
  onUpdateState: (slots: ParkingSlot[], logs: ActivityLog[], tickets: SupportTicket[]) => void;
}

export const MapView: React.FC<MapViewProps> = ({
  slots,
  logs,
  tickets,
  onUpdateState
}) => {
  const [activeSector, setActiveSector] = useState<'A' | 'B' | 'C'>('A');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSlot, setSelectedSlot] = useState<ParkingSlot | null>(null);

  // States color configuration
  const statusConfig = {
    libre: { bg: 'bg-[#22c55e]', text: 'text-[#22c55e]', label: 'libre', hex: '#22c55e' },
    ocupado: { bg: 'bg-[#ef4444]', text: 'text-[#ef4444]', label: 'ocupado', hex: '#ef4444' },
    reservado: { bg: 'bg-[#facc15]', text: 'text-[#facc15]', label: 'reservado', hex: '#facc15' },
    mantenimiento: { bg: 'bg-[#EAB308]', text: 'text-[#EAB308]', label: 'mantenimiento', hex: '#EAB308', icon: 'warning' },
    discapacitado: { bg: 'bg-[#1976D2]', text: 'text-[#1976D2]', label: 'PMR', hex: '#1976D2', icon: 'accessible' }
  };

  const getSlotProps = (estado: string) => {
    switch (estado) {
      case 'libre':
        return { fill: '#22c55e', text: 'Libre', label: 'L' }; // Match nice pre-set green
      case 'ocupado':
        return { fill: '#ef4444', text: 'Ocupado', label: 'O' }; // Doc red
      case 'reservado':
        return { fill: '#facc15', text: 'Reservado', label: 'R' }; // Yellow
      case 'mantenimiento':
        return { fill: '#EAB308', text: 'Bloqueado', label: 'M' }; // Yellow
      case 'discapacitado':
        return { fill: '#1976D2', text: 'PMR', label: '♿' }; // PMR sky blue
      default:
        return { fill: '#94a3b8', text: 'Desconocido', label: '?' };
    }
  };

  // Filter slots by sector and search query
  const filteredSlots = slots.filter((slot) => {
    const matchesSector = slot.sector === activeSector;
    const matchesSearch = 
      slot.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
      (slot.ocupante?.nombre.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (slot.ocupante?.patente.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (searchQuery) {
      return matchesSearch; // Global query across sectors
    }
    return matchesSector;
  });

  // Handle slot interaction
  const handleSlotClick = (slot: ParkingSlot) => {
    setSelectedSlot(slot);
  };

  // Handle slot administration (updating status live!)
  const handleUpdateSlotStatus = (newStatus: ParkingSlot['estado']) => {
    if (!selectedSlot) return;

    let updatedOcupante = selectedSlot.ocupante;
    if (newStatus === 'libre' || newStatus === 'mantenimiento') {
      updatedOcupante = undefined;
    } else if (!updatedOcupante) {
      // Allocate automatic dummy occupant
      updatedOcupante = {
        nombre: 'Conductor Enrolado',
        rut: '17.399.201-9',
        patente: 'HR-PX-45',
        marca: 'Suzuki',
        modelo: 'Swift',
        color: 'Azul',
        entrada: new Date().toISOString()
      };
    }

    const updatedSlots = slots.map((s) => {
      if (s.id === selectedSlot.id) {
        return {
          ...s,
          estado: newStatus,
          ocupante: updatedOcupante
        };
      }
      return s;
    });

    // Post an audit activity log
    const logType = 'entrada_detectada';
    const auditLog: ActivityLog = {
      id: `log-${Date.now()}`,
      tipo: logType as any,
      titulo: `Espacio ${selectedSlot.id} Modificado`,
      detalle: `Estado cambiado a ${newStatus.toUpperCase()}`,
      haceMinutos: 0,
      timestamp: new Date().toISOString()
    };

    onUpdateState(updatedSlots, [auditLog, ...logs], tickets);
    setSelectedSlot({
      ...selectedSlot,
      estado: newStatus,
      ocupante: updatedOcupante
    });
  };

  return (
    <div className="relative font-sans text-stone-800 pb-24">
      
      {/* Sector Switcher & View Toggles */}
      <section className="px-6 pt-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        <div className="flex overflow-x-auto pb-1 gap-2 no-scrollbar">
          {(['A', 'B', 'C'] as const).map((sec) => (
            <button
              key={sec}
              onClick={() => {
                setActiveSector(sec);
                setSearchQuery('');
              }}
              className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all border shrink-0 cursor-pointer text-center ${activeSector === sec && !searchQuery ? 'bg-[#004481] text-white border-transparent shadow' : 'bg-white text-[#44474e] border-stone-200 hover:bg-stone-50 active:scale-95'}`}
            >
              Sector {sec}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={() => {
              setActiveSector('A');
              setSearchQuery('');
              setSelectedSlot(null);
            }}
            className="flex items-center gap-1.5 px-4 py-2 bg-white border border-[#c4c6d0] rounded-lg text-xs text-[#44474e] hover:text-[#004481] transition-colors shadow-sm cursor-pointer active:scale-95"
          >
            <span className="material-symbols-outlined text-sm">fullscreen</span>
            <span>Establecer Vista</span>
          </button>
        </div>

      </section>

      {/* Legend Block */}
      <section className="px-6 py-4">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 p-3 bg-white rounded-xl border border-stone-200 shadow-sm">
          <div className="flex items-center gap-2 text-xs">
            <div className="w-4 h-4 rounded-sm bg-[#22c55e]"></div>
            <span className="font-sans font-bold text-stone-600">Libre (Verde)</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <div className="w-4 h-4 rounded-sm bg-[#ef4444]"></div>
            <span className="font-sans font-bold text-stone-600">Ocupado (Rojo)</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <div className="w-4 h-4 rounded-sm bg-[#facc15]"></div>
            <span className="font-sans font-bold text-stone-600">Reservado (Amarillo)</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <div className="w-4 h-4 rounded-sm bg-[#EAB308] flex items-center justify-center text-white font-black text-[9px]">
              ⚠
            </div>
            <span className="font-sans font-bold text-stone-600">Mantenimiento</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <div className="w-4 h-4 rounded-sm bg-[#1976D2] flex items-center justify-center text-white font-black text-[9px]">
              ♿
            </div>
            <span className="font-sans font-bold text-stone-600">PMR (Movilidad C.)</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <div className="w-4 h-4 rounded-sm bg-[#D32F2F] flex items-center justify-center text-white font-black text-[9px]">
              !
            </div>
            <span className="font-sans font-bold text-[#D32F2F] font-extrabold">Infracción</span>
          </div>
        </div>
      </section>

      {/* Main Grid Viewport */}
      <section className="px-6 flex flex-col md:flex-row gap-6 items-start">
        <div className="w-full flex-grow bg-slate-50 p-6 rounded-2xl border border-slate-200 shadow-inner flex flex-col items-center">
          
          {/* Header row in map card */}
          <div className="w-full flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-6">
            <div className="space-y-0.5">
              <h2 className="font-hanken text-xl font-extrabold text-[#004481]">
                {searchQuery ? `Resultados búsqueda: "${searchQuery}"` : `Sede Maipú • Sectores`}
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                {searchQuery ? 'Slots filtrados por coincidencia general' : `Visualizando Sector ${activeSector} (Activo)`}
              </p>
            </div>
            
            {/* Search Input tool */}
            <div className="relative">
              <input 
                className="w-full sm:w-64 bg-white border border-slate-200 rounded-lg pl-9 pr-4 py-2 text-xs focus:border-[#004481] focus:ring-2 focus:ring-[#004481]/15 outline-none transition-all placeholder:text-slate-400 font-medium" 
                placeholder="Buscar por lugar, patente o conductor..."
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-lg">
                search
              </span>
            </div>
          </div>

          {/* Sede Maipú Map Interactive SVG Container */}
          <div className="w-full overflow-x-auto pb-4 no-scrollbar">
            <div className="min-w-[980px] p-4 bg-white rounded-2xl border border-slate-100 shadow-xs flex justify-center">
              <svg 
                viewBox="0 0 980 760" 
                width={980} 
                height={760} 
                className="select-none transition-all"
              >
                {/* SVG Style definitions */}
                <defs>
                  <filter id="shadow" x="-5%" y="-5%" width="110%" height="110%">
                    <feDropShadow dx="0" dy="1" stdDeviation="1" floodColor="#000000" floodOpacity="0.08" />
                  </filter>
                  <filter id="glow" x="-10%" y="-10%" width="120%" height="120%">
                    <feDropShadow dx="0" dy="0" stdDeviation="3" floodColor="#FFD700" floodOpacity="0.5" />
                  </filter>
                </defs>

                {/* Map Surrounding Streets & Boundaries */}
                <rect x="10" y="10" width="960" height="740" rx="16" fill="#f8fafc" stroke="#e2e8f0" strokeWidth="2" />
                
                {/* Driveway 1: Top horizontal traffic lane - Callejón Norte */}
                <rect x="140" y="108" width="700" height="28" rx="8" fill="#f1f5f9" />
                <line x1="140" y1="122" x2="840" y2="122" stroke="#ea580c" strokeWidth="1" strokeDasharray="5,7" opacity="0.3" />
                <text x="490" y="126" fill="#94a3b8" fontSize="10" fontFamily="monospace" fontWeight="bold" letterSpacing="0.1em" textAnchor="middle">
                  ▲ VÍA CENTRAL INGRESO NORTE ▲
                </text>

                {/* Driveway 2: Mid horizontal traffic lane - Conexión Principal */}
                <rect x="230" y="322" width="510" height="34" rx="8" fill="#f1f5f9" />
                <line x1="230" y1="339" x2="740" y2="339" stroke="#94a3b8" strokeWidth="1" strokeDasharray="4,6" opacity="0.4" />
                <text x="485" y="343" fill="#94a3b8" fontSize="10" fontFamily="monospace" fontWeight="bold" letterSpacing="0.1em" textAnchor="middle">
                  ◀ BUCLE DE CONEXIÓN SUBTERRÁNEA ▶
                </text>

                {/* Driveway 3: Bot horizontal traffic lane - Sector F */}
                <rect x="230" y="505" width="510" height="28" rx="8" fill="#f1f5f9" />
                <line x1="230" y1="519" x2="740" y2="519" stroke="#ea580c" strokeWidth="1" strokeDasharray="5,7" opacity="0.3" />
                <text x="485" y="523" fill="#94a3b8" fontSize="10" fontFamily="monospace" fontWeight="bold" letterSpacing="0.1em" textAnchor="middle">
                  ▼ PROTOCOLO DE SALIDA EXTRAPOLADA ▼
                </text>

                {/* Ramps and Ingress Icons */}
                <g opacity="0.3" transform="translate(45, 30)">
                  <path d="M0,0 L20,10 L0,20 Z" fill="#94a3b8" />
                  <text x="25" y="14" fill="#94a3b8" fontSize="9" fontWeight="bold" fontFamily="monospace">ACCESO ACCESIBLE</text>
                </g>

                <g opacity="0.3" transform="translate(900, 715)">
                  <path d="M10,0 L0,10 L20,10 Z" fill="#94a3b8" />
                  <text x="-80" y="9" fill="#94a3b8" fontSize="9" fontWeight="bold" fontFamily="monospace">SALIDA DE EMERGENCIA</text>
                </g>

                {/* Sector Watermark labels in background */}
                <text x="490" y="82" fill="#cbd5e1" fontSize="11" fontFamily="monospace" fontWeight="extraBold" opacity="0.6" letterSpacing="0.2em" textAnchor="middle">
                  SECTOR A (FILAS A - B - C)
                </text>
                <text x="495" y="475" fill="#cbd5e1" fontSize="11" fontFamily="monospace" fontWeight="extraBold" opacity="0.6" letterSpacing="0.2em" textAnchor="middle">
                  SECTOR B (FILAS D - E - F)
                </text>
                <text x="890" y="125" fill="#cbd5e1" fontSize="11" fontFamily="monospace" fontWeight="extraBold" opacity="0.6" letterSpacing="0.2em" textAnchor="middle" transform="rotate(90 890 125)">
                  SECTOR C (COLUMNAS R1 - R2)
                </text>
                <text x="50" y="400" fill="#cbd5e1" fontSize="11" fontFamily="monospace" fontWeight="extraBold" opacity="0.6" letterSpacing="0.15em" textAnchor="middle" transform="rotate(-90 50 400)">
                  RAMPA INCLINADA ACCESO NORTE (COLUMNA L)
                </text>

                {/* Parking Slots Node Renderer */}
                <g id="parking">
                  {(() => {
                    // Coordinate layout maps
                    const W_S = 30;
                    const H_S = 56;
                    const GAP_X_S = 8;
                    const LAY_CONF = [
                      { type: 'row', prefix: 'A', x: 170, y: 40, count: 18 },
                      { type: 'row', prefix: 'B', x: 250, y: 150, count: 12 },
                      { type: 'row', prefix: 'C', x: 250, y: 255, count: 12 },
                      { type: 'row', prefix: 'D', x: 320, y: 370, count: 10 },
                      { type: 'row', prefix: 'E', x: 320, y: 435, count: 10 },
                      { type: 'row', prefix: 'F', x: 300, y: 585, count: 10 },
                      { type: 'column', prefix: 'L', x: 90, y: 170, count: 12, angle: -12 },
                      { type: 'column', prefix: 'R1', x: 760, y: 140, count: 13 },
                      { type: 'column', prefix: 'R2', x: 815, y: 140, count: 13 }
                    ];

                    let seedCounter = 0;
                    const visualSlotsList = LAY_CONF.flatMap((block) => {
                      const list = [];
                      for (let i = 0; i < block.count; i++) {
                        const visualId = `${block.prefix}${String(i + 1).padStart(2, '0')}`;
                        const x = block.type === 'row'
                          ? block.x + i * (W_S + GAP_X_S)
                          : block.x;
                        const y = block.type === 'column'
                          ? block.y + i * (H_S - 10)
                          : block.y;
                        
                        list.push({
                          visualId,
                          prefix: block.prefix,
                          indexInBlock: i,
                          x,
                          y,
                          angle: block.angle || 0,
                          globalIndex: seedCounter++
                        });
                      }
                      return list;
                    });

                    return visualSlotsList.map((item) => {
                      const dbSlot = slots[item.globalIndex];
                      if (!dbSlot) return null;

                      // Determine filters: matched by search, matched by active sector tab
                      const matchesSearch = searchQuery ? (
                        dbSlot.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        (dbSlot.ocupante?.nombre && dbSlot.ocupante.nombre.toLowerCase().includes(searchQuery.toLowerCase())) ||
                        (dbSlot.ocupante?.patente && dbSlot.ocupante.patente.toLowerCase().includes(searchQuery.toLowerCase()))
                      ) : true;

                      const matchesSectorTab = dbSlot.sector === activeSector;
                      const isHighlighted = searchQuery ? matchesSearch : matchesSectorTab;

                      // Interactive Selection Status
                      const isSelected = selectedSlot?.id === dbSlot.id;
                      const isPreAllocatedDriverSlot = dbSlot.numero === 15; // User designated spot

                      // Custom status configurations
                      const fillProps = getSlotProps(dbSlot.estado);

                      return (
                        <g 
                          key={dbSlot.id}
                          transform={`translate(${item.x} ${item.y}) rotate(${item.angle} ${W_S / 2} ${H_S / 2})`}
                          onClick={() => handleSlotClick(dbSlot)}
                          style={{ cursor: 'pointer' }}
                          className="group"
                          opacity={isHighlighted ? 1 : 0.22}
                        >
                          {/* Selection indicator halo */}
                          {isSelected && (
                            <rect 
                              x={-4}
                              y={-4}
                              width={W_S + 8}
                              height={H_S + 8}
                              rx={8}
                              ry={8}
                              fill="none"
                              stroke="#FFD700"
                              strokeWidth={3}
                              filter="url(#glow)"
                            />
                          )}

                          {/* Base parking block card */}
                          <rect 
                            x={0}
                            y={0}
                            width={W_S}
                            height={H_S}
                            rx={5}
                            ry={5}
                            fill={fillProps.fill}
                            stroke={isSelected ? '#ffffff' : (isPreAllocatedDriverSlot ? '#FFD700' : '#475569')}
                            strokeWidth={isSelected ? 2 : (isPreAllocatedDriverSlot ? 2.5 : 1)}
                            filter="url(#shadow)"
                            className="transition-all duration-150 group-hover:brightness-110"
                          />

                          {/* Preoccupied Driver Slot Indicator Overlay */}
                          {isPreAllocatedDriverSlot && (
                            <rect 
                              x={2}
                              y={2}
                              width={W_S - 4}
                              height={4}
                              rx={1}
                              fill="#FFD700"
                            />
                          )}

                          {/* Slot visual ID label */}
                          <text 
                            x={W_S / 2} 
                            y={18} 
                            fill={dbSlot.estado === 'libre' ? '#ffffff' : '#ffffff'} 
                            fontSize={7.5} 
                            fontWeight="900" 
                            fontFamily="monospace"
                            letterSpacing="-0.02em"
                            textAnchor="middle"
                            opacity={0.95}
                          >
                            {dbSlot.id}
                          </text>

                          {/* Status symbol indicator (emoji representation inside card) */}
                          <text 
                            x={W_S / 2} 
                            y={35} 
                            fill="#ffffff" 
                            fontSize={11} 
                            textAnchor="middle"
                          >
                            {fillProps.label}
                          </text>

                          {/* Mini numerical reference label */}
                          <text 
                            x={W_S / 2} 
                            y={48} 
                            fill="#ffffff" 
                            fontSize={6.5} 
                            fontFamily="sans-serif"
                            fontWeight="bold"
                            opacity="0.75"
                            textAnchor="middle"
                          >
                            N°{dbSlot.numero}
                          </text>

                          {/* Tooltip text inside SVG */}
                          <title>{`Código: ${dbSlot.id}\nEstado: ${fillProps.text.toUpperCase()}\nSector: ${dbSlot.sector}\n${dbSlot.ocupante ? `Vehículo: ${dbSlot.ocupante.patente} (${dbSlot.ocupante.nombre})` : 'Disponibilidad inmediata'}`}</title>
                        </g>
                      );
                    });
                  })()}
                </g>
              </svg>
            </div>
          </div>

          {/* Quick status guide helper */}
          <div className="w-full mt-2 flex justify-between items-center text-xs text-slate-500 font-medium px-2">
            <span>Usa Click sobre cualquier espacio del mapa para administrar o ver detalles.</span>
            <span>Estacionamiento total: 110 espacios activos</span>
          </div>

        </div>


        {/* Modal Overlay Detail Card for Selected Slot */}
        {selectedSlot && (
          <div 
            className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs animate-fade-in"
            onClick={() => setSelectedSlot(null)}
          >
            <aside 
              id="selected-slot-modal"
              className="w-full max-w-md bg-white border border-slate-200 rounded-2xl p-6 shadow-2xl space-y-4 animate-zoom-in relative"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                <div>
                  <span className="font-mono text-xs text-[#004481] font-bold">CÓDIGO DE ESPACIO: {selectedSlot.id}</span>
                  <h3 className={`font-hanken text-lg font-black capitalize ${statusConfig[selectedSlot.estado]?.text}`}>
                    {statusConfig[selectedSlot.estado]?.label || selectedSlot.estado}
                  </h3>
                </div>
                <button 
                  onClick={() => setSelectedSlot(null)}
                  className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer transition-colors"
                >
                  <span className="material-symbols-outlined text-2xl">close</span>
                </button>
              </div>

              {/* Occupant card if occupied */}
              {selectedSlot.ocupante ? (
                <div className="space-y-2.5">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <p className="text-[10px] uppercase font-mono font-bold text-slate-400">Patente Vehicular</p>
                    <p className="font-mono text-xl font-extrabold text-[#004481]">{selectedSlot.ocupante.patente}</p>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <p className="text-[10px] uppercase font-mono font-bold text-slate-400">Conductor</p>
                    <p className="font-sans text-sm font-bold text-slate-800">{selectedSlot.ocupante.nombre}</p>
                    <p className="font-mono text-[10px] text-slate-500 mt-0.5">RUT: {selectedSlot.ocupante.rut}</p>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <p className="text-[10px] uppercase font-mono font-bold text-slate-400">Vehículo</p>
                    <p className="text-xs font-semibold text-slate-700">
                      {selectedSlot.ocupante.marca} {selectedSlot.ocupante.modelo} ({selectedSlot.ocupante.color})
                    </p>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <p className="text-[10px] uppercase font-mono font-bold text-slate-400">Ingreso Registrado</p>
                    <p className="text-xs font-semibold text-slate-700">
                      {new Date(selectedSlot.ocupante.entrada).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} hrs
                    </p>
                  </div>
                </div>
              ) : (
                <div className="py-8 text-center text-slate-400 text-xs font-medium italic border border-dashed border-slate-200 rounded-xl bg-slate-50">
                  Espacio desocupado actualmente
                </div>
              )}

              {/* Administrate Space Toolbar */}
              <div className="pt-4 border-t border-slate-100 space-y-2.5">
                <p className="text-[10px] uppercase font-mono font-bold text-slate-400">Control de Espacio (Simulación en Vivo):</p>
                
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleUpdateSlotStatus('libre')}
                    disabled={selectedSlot.estado === 'libre'}
                    className="px-2.5 py-2 border border-[#22c55e] text-[#22c55e] rounded-lg text-xs font-bold hover:bg-green-50/50 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed transition-all"
                  >
                    Liberar
                  </button>
                  <button
                    onClick={() => handleUpdateSlotStatus('ocupado')}
                    disabled={selectedSlot.estado === 'ocupado'}
                    className="px-2.5 py-2 border border-[#ef4444] text-[#ef4444] rounded-lg text-xs font-bold hover:bg-red-50/50 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed transition-all"
                  >
                    Ocupar
                  </button>
                </div>

                <div className="grid grid-cols-1">
                  <button
                    onClick={() => handleUpdateSlotStatus('mantenimiento')}
                    disabled={selectedSlot.estado === 'mantenimiento'}
                    className="px-2.5 py-2.5 bg-[#EAB308] hover:bg-[#caa007] text-white rounded-lg text-xs font-bold disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed transition-all text-center flex items-center justify-center gap-1.5"
                  >
                    <span className="material-symbols-outlined text-sm font-semibold">build</span>
                    <span>Marcar en Mantenimiento / Bloquear</span>
                  </button>
                </div>
              </div>

              {/* Bottom Dismiss */}
              <div className="pt-2">
                <button
                  onClick={() => setSelectedSlot(null)}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-all cursor-pointer text-center"
                >
                  Cerrar Detalles
                </button>
              </div>

            </aside>
          </div>
        )}
      </section>

    </div>
  );
};
