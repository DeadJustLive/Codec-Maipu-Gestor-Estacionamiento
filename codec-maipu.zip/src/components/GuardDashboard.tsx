import React, { useState } from 'react';
import { ParkingSlot, ActivityLog, SupportTicket } from '../types';

interface GuardDashboardProps {
  slots: ParkingSlot[];
  logs: ActivityLog[];
  tickets: SupportTicket[];
  onNavigate: (tab: string) => void;
  onUpdateState: (slots: ParkingSlot[], logs: ActivityLog[], tickets: SupportTicket[]) => void;
  currentUser: { nombre: string; role: string; avatar: string };
}

export const GuardDashboard: React.FC<GuardDashboardProps> = ({
  slots,
  logs,
  tickets,
  onNavigate,
  onUpdateState,
  currentUser
}) => {
  const [showScanner, setShowScanner] = useState(false);
  const [scannedResult, setScannedResult] = useState<{ slotId: string; status: 'ok' | 'fail'; msg: string } | null>(null);
  const [showIncidentModal, setShowIncidentModal] = useState(false);
  const [incidentSlot, setIncidentSlot] = useState('');
  const [incidentType, setIncidentType] = useState<'problema' | 'consulta' | 'reporte'>('problema');
  const [incidentMsg, setIncidentMsg] = useState('');

  // Calculate live statistics
  const totalSlots = slots.length;
  const occupiedCount = slots.filter(s => s.estado === 'ocupado').length;
  const freeCount = slots.filter(s => s.estado === 'libre' || s.estado === 'discapacitado').length;
  const occupiedPct = Math.round((occupiedCount / totalSlots) * 100);
  const maintenanceCount = slots.filter(s => s.estado === 'mantenimiento').length;
  const reservadoCount = slots.filter(s => s.estado === 'reservado').length;

  // Handle Scanning Simulation
  const handleSimulationScan = (slotId: string) => {
    const slot = slots.find(s => s.id === slotId);
    if (!slot) return;

    if (slot.estado === 'mantenimiento') {
      setScannedResult({
        slotId,
        status: 'fail',
        msg: `ESPACIO BLOQUEADO: El espacio ${slotId} está actualmente en mantenimiento o fuera de servicio.`
      });
      
      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        tipo: 'sensor_offline',
        titulo: 'Acceso Denegado',
        detalle: `Espacio ${slotId} en mantenimiento`,
        haceMinutos: 0,
        timestamp: new Date().toISOString()
      };
      onUpdateState(slots, [newLog, ...logs], tickets);
    } else {
      // Mark as Verified OK
      const updatedSlots = slots.map(s => {
        if (s.id === slotId && s.ocupante) {
          return {
            ...s,
            ocupante: { ...s.ocupante, verificado: true }
          };
        }
        return s;
      });

      setScannedResult({
        slotId,
        status: 'ok',
        msg: `ACCESO VERIFICADO ✔: Espacio ${slotId} asignado a ${slot.ocupante?.nombre || 'Daniel Reyes'} (${slot.ocupante?.patente || 'AA-452-BB'})`
      });

      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        tipo: 'entrada_detectada',
        titulo: 'Verificación Exitosa',
        detalle: `Espacio ${slotId} • Código QR Validado`,
        haceMinutos: 0,
        timestamp: new Date().toISOString()
      };
      
      onUpdateState(updatedSlots, [newLog, ...logs], tickets);
    }
  };

  // Create customized Incident ticket
  const handleCreateIncident = (e: React.FormEvent) => {
    e.preventDefault();
    if (!incidentMsg.trim()) return;

    const newTicket: SupportTicket = {
      id: `t-custom-${Date.now()}`,
      usuarioNombre: 'Guardia Martínez',
      usuarioRut: '12.345.678-9',
      tipo: incidentType,
      estado: 'abierto',
      mensaje: `[Espacio ${incidentSlot || 'N/A'}] ${incidentMsg}`,
      haceTiempo: 'Hace 1 min',
      created_at: new Date().toISOString(),
      respuestas: []
    };

    // Update slots if matching reports
    let updatedSlots = [...slots];
    if (incidentSlot && incidentType === 'reporte') {
      updatedSlots = slots.map(s => {
        if (s.id === incidentSlot) {
          return {
            ...s,
            estado: 'mantenimiento' as const,
            ocupante: {
              nombre: 'Vehículo Bloqueador',
              rut: '---',
              patente: 'INCIDENCIA-TR',
              marca: 'Desconocido',
              modelo: 'Vehículo',
              color: 'Automóvil',
              entrada: new Date().toISOString()
            }
          };
        }
        return s;
      });
    }

    onUpdateState(updatedSlots, logs, [newTicket, ...tickets]);
    
    // Reset Form
    setIncidentMsg('');
    setIncidentSlot('');
    setShowIncidentModal(false);
  };

  return (
    <div className="relative font-sans text-slate-850 selection:bg-[#004481]/10 pb-32">
      
      {/* Control Center Header */}
      <section className="px-6 pt-6 pb-2">
        <div className="flex flex-col gap-1">
          <span className="font-mono text-xs text-[#004481] uppercase tracking-widest font-bold">
            Estación Central
          </span>
          <h2 className="font-hanken text-3xl font-extrabold text-slate-900">
            Panel de Control
          </h2>
        </div>
      </section>

      {/* KPI Grid */}
      <section className="px-6 py-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* KPI: Ocupación */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start mb-2">
              <span className="font-mono text-[11px] text-slate-500 uppercase font-bold tracking-wider">
                Ocupación %
              </span>
              <span className="material-symbols-outlined text-[#004481]">percent</span>
            </div>
            <div className="font-hanken text-5xl font-extrabold text-slate-900">
              {occupiedPct}<span className="text-xl font-medium">%</span>
            </div>
            <div className="mt-3 w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div className="bg-[#004481] h-full transition-all duration-500" style={{ width: `${occupiedPct}%` }}></div>
            </div>
          </div>

          {/* KPI: Libres */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start mb-2">
              <span className="font-mono text-[11px] text-slate-500 uppercase font-bold tracking-wider">
                Libres
              </span>
              <span className="material-symbols-outlined text-green-600">check_circle</span>
            </div>
            <div className="font-hanken text-5xl font-extrabold text-green-600">
              {freeCount}
            </div>
            <p className="text-xs text-slate-500 mt-2 font-medium">
              {reservadoCount} espacios reservados hoy
            </p>
          </div>

          {/* KPI: Mantenimiento */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start mb-2">
              <span className="font-mono text-[11px] text-slate-500 uppercase font-bold tracking-wider">
                Mantenimiento
              </span>
              <span className="material-symbols-outlined text-[#EAB308] font-bold" style={{ fontVariationSettings: "'FILL' 1" }}>
                build
              </span>
            </div>
            <div className="font-hanken text-5xl font-extrabold text-[#EAB308]">
              {String(maintenanceCount).padStart(2, '0')}
            </div>
            <p className="text-xs text-amber-700 mt-2 font-semibold bg-amber-50 py-1 px-2 rounded-md self-start border border-amber-200">
              Espacios fuera de servicio
            </p>
          </div>
          
        </div>
      </section>

      {/* Quick Actions */}
      <section className="px-6 py-2">
        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={() => setShowScanner(true)}
            className="bg-[#004481] hover:bg-[#003362] text-white font-bold py-4 px-4 rounded-xl flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md cursor-pointer"
          >
            <span className="material-symbols-outlined">qr_code_scanner</span>
            <span className="text-slate-100 text-sm font-semibold tracking-wide uppercase">Escaneo QR</span>
          </button>
          
          <button 
            onClick={() => setShowIncidentModal(true)}
            className="bg-slate-600 hover:bg-slate-700 text-white font-bold py-4 px-4 rounded-xl flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md cursor-pointer"
          >
            <span className="material-symbols-outlined">report_problem</span>
            <span className="text-slate-100 text-sm font-semibold tracking-wide uppercase">Incidencia</span>
          </button>
        </div>
      </section>

      {/* Activity Feed */}
      <section className="px-6 py-6">
        <div className="flex justify-between items-end mb-4">
          <h3 className="font-hanken text-xl font-extrabold text-slate-900">
            Actividad Reciente
          </h3>
          <button 
            onClick={() => onNavigate('mapa')}
            className="text-[#004481] font-bold text-xs hover:underline cursor-pointer"
          >
            Ver todo el Mapa
          </button>
        </div>

        <div className="space-y-3">
          {logs.map((log) => {
            let icon = 'event_busy';
            let bgClass = 'bg-red-105 text-red-700';
            
            if (log.tipo === 'entrada_detectada') {
              icon = 'login';
              bgClass = 'bg-slate-100 text-blue-700';
            } else if (log.tipo === 'sensor_offline') {
              icon = 'build';
              bgClass = 'bg-slate-100 text-slate-600';
            }

            return (
              <div 
                key={log.id}
                className="bg-slate-50 hover:bg-slate-100 p-4 rounded-xl flex items-center gap-4 border border-slate-200 transition-colors shadow-xs"
              >
                <div className={`w-10 h-10 rounded-full ${bgClass} flex items-center justify-center shrink-0`}>
                  <span className="material-symbols-outlined">{icon}</span>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-slate-900 text-sm truncate">{log.titulo}</span>
                    <span className="text-[10px] font-mono text-slate-500 uppercase font-semibold">
                      Hace {log.haceMinutos} min
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 truncate">{log.detalle}</p>
                </div>

                <span className="material-symbols-outlined text-slate-400">chevron_right</span>
              </div>
            );
          })}
        </div>
      </section>

      {/* Floating scanner button */}
      <button 
        onClick={() => setShowScanner(true)}
        className="fixed right-6 bottom-24 w-14 h-14 bg-[#004481] hover:bg-[#003362] text-white rounded-full shadow-2xl flex items-center justify-center active:scale-95 transition-transform z-40 border-4 border-[#fcf9f8] cursor-pointer"
      >
        <span className="material-symbols-outlined text-[32px]">qr_code_scanner</span>
      </button>

      {/* MODAL 1: QR Scanning Simulation Overlay */}
      {showScanner && (
        <div className="fixed inset-0 bg-slate-900/80 z-50 flex flex-col justify-center items-center p-6 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 relative flex flex-col border border-slate-200 shadow-2xl">
            <button 
              onClick={() => {
                setShowScanner(false);
                setScannedResult(null);
              }}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <span className="material-symbols-outlined text-3xl">close</span>
            </button>

            <div className="text-center mb-6">
              <span className="material-symbols-outlined text-5xl text-[#004481] mb-2">qr_code_scanner</span>
              <h3 className="font-hanken text-lg font-extrabold text-slate-900 mb-1">Simulador de Escáner QR (Guardia)</h3>
              <p className="text-xs text-slate-400 mt-1">
                La patrulla de seguridad lee los códigos QR de la tarjeta colgada del retrovisor en terreno.
              </p>
            </div>

            {/* Viewfinder simulation */}
            <div className="relative border-4 border-dashed border-[#004481]/70 rounded-xl overflow-hidden aspect-video bg-slate-50 flex items-center justify-center mb-4 shadow-inner">
              <div className="absolute inset-x-0 h-0.5 bg-red-500 timeline-scan animate-bounce"></div>
              {scannedResult ? (
                <div className={`p-4 mx-4 rounded-lg text-center ${scannedResult.status === 'ok' ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                  <span className={`material-symbols-outlined text-3xl ${scannedResult.status === 'ok' ? 'text-green-600' : 'text-red-600'}`}>
                    {scannedResult.status === 'ok' ? 'check_circle' : 'warning'}
                  </span>
                  <p className={`text-xs font-bold mt-2 ${scannedResult.status === 'ok' ? 'text-green-800' : 'text-red-800'}`}>
                    {scannedResult.msg}
                  </p>
                </div>
              ) : (
                <div className="text-center p-4">
                  <p className="text-xs text-slate-500 font-medium font-sans">Buscando Código QR...</p>
                  <p className="text-[10px] text-slate-400 mt-0.5 font-mono">Seleccione qué espacio simular abajo:</p>
                </div>
              )}
            </div>

            {/* Simulated options list */}
            <div>
              <label className="text-xs font-extrabold text-slate-500 block mb-2 uppercase tracking-tight">Presione un espacio para simular lectura en vivo:</label>
              <div className="grid grid-cols-2 gap-2 h-44 overflow-y-auto pr-1">
                {slots.filter(s => s.ocupante).map(s => {
                  let badgeColor = 'bg-slate-100 text-slate-700';
                  if (s.estado === 'mantenimiento') badgeColor = 'bg-amber-100 text-amber-700';
                  if (s.estado === 'reservado') badgeColor = 'bg-orange-100 text-orange-700';
                  
                  return (
                    <button
                      key={s.id}
                      onClick={() => handleSimulationScan(s.id)}
                      className="p-2 border border-slate-200 rounded-lg text-left hover:bg-slate-50 active:scale-95 transition-all text-xs cursor-pointer flex flex-col justify-between"
                    >
                      <div className="flex justify-between items-center w-full mb-1">
                        <span className="font-bold text-[#004481]">{s.id}</span>
                        <span className={`text-[9px] px-1.5 rounded uppercase font-extrabold ${badgeColor}`}>{s.estado}</span>
                      </div>
                      <span className="text-slate-500 text-[10px] truncate">Patente: {s.ocupante?.patente}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-6 flex gap-2">
              <button
                onClick={() => {
                  setShowScanner(false);
                  setScannedResult(null);
                }}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-semibold cursor-pointer transition-colors"
              >
                Cerrar Cámara
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Create Incident / Report Blockage */}
      {showIncidentModal && (
        <div className="fixed inset-0 bg-slate-900/80 z-50 flex h-full items-center justify-center p-6 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 relative shadow-2xl border border-slate-200">
            <button 
              onClick={() => setShowIncidentModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <span className="material-symbols-outlined text-2xl">close</span>
            </button>

            <h3 className="font-hanken text-lg font-extrabold text-slate-900 flex items-center gap-2 mb-2">
              <span className="material-symbols-outlined text-red-650">report_problem</span>
              Levantar Reporte de Incidencia
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Informe al centro de mando sobre sensores con fallos, vehículos mal estacionados o sospechas de infracciones.
            </p>

            <form onSubmit={handleCreateIncident} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Espacio de Parking (Opcional)</label>
                <select 
                  value={incidentSlot}
                  onChange={(e) => setIncidentSlot(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#004481] focus:ring-1 focus:ring-[#004481]/15 font-medium"
                >
                  <option value="">-- No aplica / General --</option>
                  {slots.slice(0, 30).map(s => (
                    <option key={s.id} value={s.id}>{s.id} (Disponibilidad: {s.estado})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Categoría</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setIncidentType('problema')}
                    className={`py-2 px-3 border rounded-lg text-xs font-bold capitalize cursor-pointer transition-colors ${incidentType === 'problema' ? 'bg-[#004481] text-white border-[#004481]' : 'bg-white text-slate-600 border-slate-205'}`}
                  >
                    Problema
                  </button>
                  <button
                    type="button"
                    onClick={() => setIncidentType('consulta')}
                    className={`py-2 px-3 border rounded-lg text-xs font-bold capitalize cursor-pointer transition-colors ${incidentType === 'consulta' ? 'bg-[#004481] text-white border-[#004481]' : 'bg-white text-slate-600 border-slate-205'}`}
                  >
                    Consulta
                  </button>
                  <button
                    type="button"
                    onClick={() => setIncidentType('reporte')}
                    className={`py-2 px-3 border rounded-lg text-xs font-bold capitalize cursor-pointer transition-colors ${incidentType === 'reporte' ? 'bg-[#004481] text-white border-[#004481]' : 'bg-white text-slate-600 border-slate-205'}`}
                  >
                    Reporte
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wide block mb-1">Mensaje Explicativo</label>
                <textarea
                  value={incidentMsg}
                  onChange={(e) => setIncidentMsg(e.target.value)}
                  placeholder="Detalles de la anomalía, ej: Vehículo bloquea salida con patente..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#004481] focus:ring-1 focus:ring-[#004481]/15 h-24 resize-none"
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowIncidentModal(false)}
                  className="w-1/2 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-sm font-semibold cursor-pointer transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-[#004481] hover:bg-[#003362] text-white rounded-lg text-sm font-bold shadow cursor-pointer transition-all animate-fade-in"
                >
                  Confirmar Incidencia
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
