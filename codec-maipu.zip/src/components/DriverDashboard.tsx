import React, { useState, useEffect } from 'react';
import { ParkingSlot } from '../types';

interface DriverDashboardProps {
  slots: ParkingSlot[];
  onNavigate: (tab: string) => void;
}

export const DriverDashboard: React.FC<DriverDashboardProps> = ({ slots, onNavigate }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [timeLeft, setTimeLeft] = useState(2 * 3600 + 41 * 60 + 28); // 02:41:28

  // Ticking Countdown timer
  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
  };

  // Neighborhood slot list from A-11 to A-20 around A-15
  const neighborhoodSlots = [
    { name: 'A-11', estado: 'ocupado' },
    { name: 'A-12', estado: 'libre' },
    { name: 'A-13', estado: 'libre' },
    { name: 'A-14', estado: 'ocupado' },
    { name: 'A-15', estado: 'mine' }, // Highlighted Space
    { name: 'A-16', estado: 'libre' },
    { name: 'A-17', estado: 'ocupado' },
    { name: 'A-18', estado: 'libre' },
    { name: 'A-19', estado: 'ocupado' },
    { name: 'A-20', estado: 'libre' }
  ];

  return (
    <div className="relative font-sans text-slate-800 pb-24 flex flex-col items-center select-none w-full">
      <div className="w-full max-w-5xl px-6 py-6 space-y-6">
        
        {/* Dashboard Title & Action */}
        <div className="flex justify-between items-end border-b border-slate-200 pb-4">
          <div>
            <h2 className="font-hanken text-3xl font-extrabold text-[#004481]">
              Mi Estacionamiento
            </h2>
            <p className="text-slate-500 text-sm font-medium animate-fade-in1">
              Ticket activo • Sector Central
            </p>
          </div>
          <button 
            onClick={() => setIsFullscreen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-[#004481] hover:bg-[#003362] text-white font-bold rounded-lg transition-colors cursor-pointer active:scale-95 shadow-sm"
          >
            <span className="material-symbols-outlined text-lg">fullscreen</span>
            <span className="hidden md:inline text-xs font-semibold uppercase tracking-wider">Pantalla Completa</span>
          </button>
        </div>

        {/* Main Layout Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          
          {/* Left Column: Assigned Space & QR verification card */}
          <div className="md:col-span-5 space-y-6">
            
            {/* Assigned Slot Code Card */}
            <div className="bg-white p-6 rounded-2xl border-2 border-[#004481] relative shadow-xs animate-zoom-in">
              <div className="absolute top-4 right-4 bg-[#FFD700] text-[#004481] text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                Tu Espacio
              </div>
              <span className="text-slate-400 font-mono text-xs font-bold uppercase tracking-wider block">
                CÓDIGO DE ESPACIO
              </span>
              <div className="font-hanken text-6xl font-extrabold text-[#004481] leading-none mt-2">
                A-15
              </div>
              <div className="mt-4 flex items-center gap-1.5">
                <span className="material-symbols-outlined text-green-600 font-extrabold" style={{ fontVariationSettings: "'FILL' 1" }}>
                  check_circle
                </span>
                <span className="text-green-600 font-extrabold text-xs uppercase tracking-wider">Lugar Verificado</span>
              </div>
            </div>

            {/* Digital QR verification card */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 flex flex-col items-center justify-center space-y-4 shadow-sm animate-zoom-in">
              <div className="p-4 rounded-xl border border-slate-200" style={{ background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)' }}>
                {/* Simulated QR Code matrix blocks strictly styled like screenshot */}
                <div className="w-40 h-40 bg-white p-2 rounded-sm grid grid-cols-8 grid-rows-8 gap-0.5 shadow-xs">
                  {Array.from({ length: 64 }).map((_, i) => {
                    const isBlack = (i % 3 === 0 || i % 7 === 0 || i < 12 || (i > 45 && i < 54)) && i !== 22 && i !== 35;
                    return (
                      <div 
                        key={i} 
                        className={`${isBlack ? 'bg-[#004481]' : 'bg-white'} rounded-[1px]`}
                      ></div>
                    );
                  })}
                </div>
              </div>

              <div className="text-center">
                <h3 className="font-hanken text-lg font-extrabold text-[#004481]">QR de Verificación</h3>
                <p className="text-slate-500 text-xs mt-1 px-4 leading-relaxed font-semibold text-slate-500">
                  Escanea esta tarjeta digital en los tótems para validar tu sesión de estacionamiento.
                </p>
              </div>

              <div className="w-full pt-4 border-t border-slate-100 flex justify-between items-center">
                <span className="font-mono text-xs text-slate-400 font-bold tracking-wider">EXPIRA EN:</span>
                <span className="font-mono text-base text-[#004481] font-black">{formatTime(timeLeft)}</span>
              </div>
            </div>

          </div>

          {/* Right Column: Mini Map neighborhood */}
          <div className="md:col-span-7">
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden flex flex-col h-full shadow-sm">
              
              {/* Box Header */}
              <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[#004481]">map</span>
                  <span className="font-sans text-sm text-[#004481] font-bold">Ubicación en Sector A</span>
                </div>
                <div className="flex gap-3">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-green-500 rounded-sm"></div>
                    <span className="text-[10px] text-slate-500 font-extrabold">LIBRE</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-[#004481] rounded-sm"></div>
                    <span className="text-[10px] text-slate-500 font-extrabold">OCUPADO</span>
                  </div>
                </div>
              </div>

              {/* Grid content */}
              <div className="relative flex-grow bg-slate-100 p-6 flex flex-col justify-center min-h-[300px]">
                <div className="grid grid-cols-5 gap-3 max-w-sm mx-auto w-full">
                  {neighborhoodSlots.map((slot) => {
                    let btnClass = 'bg-[#004481] text-white';
                    if (slot.estado === 'libre') {
                      btnClass = 'bg-green-500 text-white';
                    } else if (slot.estado === 'mine') {
                      btnClass = 'bg-white text-[#004481] border-4 border-[#FFD700] ring-4 ring-[#004481] scale-105 z-10 shadow-sm font-black';
                    }

                    return (
                      <div 
                        key={slot.name}
                        className={`aspect-square rounded-lg flex flex-col items-center justify-center transition-all ${btnClass}`}
                      >
                        <span className={`font-mono text-[10px] font-black ${slot.estado === 'mine' ? 'text-[#004481]' : 'text-white'}`}>
                          {slot.name}
                        </span>
                        {slot.estado === 'mine' && (
                          <span className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1 animate-ping"></span>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Floating Map Detail Bubble */}
                <div className="bg-white/95 backdrop-blur-sm p-4 rounded-xl shadow-lg border border-slate-200 max-w-[240px] mt-6 mx-auto animate-fade-in">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="w-2.5 h-2.5 bg-[#004481] rounded-full animate-pulse"></span>
                    <span className="text-[10px] uppercase font-mono font-black text-[#004481]">Posición Actual</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight font-semibold">
                    Acceso Norte. El Sector A se encuentra a 50 metros girando a la izquierda.
                  </p>
                </div>
              </div>

              {/* Card Footer Link */}
              <div className="p-4 border-t border-slate-100 bg-white">
                <button 
                  onClick={() => onNavigate('mapa')}
                  className="text-[#004481] font-bold text-xs flex items-center gap-1 hover:underline cursor-pointer"
                >
                  Ver mapa completo del campus
                  <span className="material-symbols-outlined text-sm">arrow_forward</span>
                </button>
              </div>

            </div>
          </div>

        </div>

        {/* Bottom context indicators */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col justify-center shadow-xs">
            <span className="text-slate-400 font-mono text-[10px] uppercase font-bold tracking-wider">Ocupación Sector A</span>
            <div className="font-hanken text-[#004481] text-2xl font-extrabold mt-1">65% de capacidad</div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col justify-center shadow-xs">
            <span className="text-slate-400 font-mono text-[10px] uppercase font-bold tracking-wider">Clima Exterior Sede</span>
            <div className="font-hanken text-[#004481] text-2xl font-extrabold mt-1 flex items-center gap-1.5">
              <span>24°C Despejado</span>
              <span className="text-amber-500 text-3xl font-normal leading-none mb-1">☀</span>
            </div>
          </div>
        </div>

      </div>

      {/* MODAL overlay: Fullscreen Scanning Target */}
      {isFullscreen && (
        <div className="fixed inset-0 bg-slate-900/95 z-[100] flex flex-col items-center justify-center p-6 text-center animate-zoom-in backdrop-blur-xs">
          <button 
            onClick={() => setIsFullscreen(false)}
            className="absolute top-6 right-6 text-white p-3 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-4xl font-bold">close</span>
          </button>

          <div className="space-y-8 max-w-sm">
            <div className="font-hanken text-9xl font-black text-white leading-none border-b-8 border-yellow-400 pb-2 inline-block">
              A-15
            </div>
            
            <h2 className="font-hanken text-2xl font-extrabold text-white">Sector Central - Sede Maipú</h2>
            
            <div className="bg-white p-6 rounded-3xl inline-block border border-slate-800 shadow-2xl">
              {/* Huge QR Simulator */}
              <div className="w-56 h-56 bg-white p-3 rounded-lg grid grid-cols-8 grid-rows-8 gap-0.5">
                {Array.from({ length: 64 }).map((_, i) => {
                  const isBlack = (i % 2 === 0 || i % 5 === 0 || i < 15 || i > 40) && i !== 14 && i !== 45;
                  return (
                    <div 
                      key={i} 
                      className={`${isBlack ? 'bg-[#004481]' : 'bg-white'} rounded-[2px]`}
                    ></div>
                  );
                })}
              </div>
            </div>
            
            <p className="text-slate-350 text-sm max-w-xs mx-auto leading-relaxed font-bold">
              Presente esta pantalla en el tótem o lector de la barrera para ingreso o salida rápida.
            </p>
          </div>
        </div>
      )}

    </div>
  );
};
