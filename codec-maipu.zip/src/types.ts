export type UserRole = 'conductor' | 'guardia' | 'directivo';

export interface UserProfile {
  rut: string;
  nombre: string;
  email: string;
  role: UserRole;
  avatar: string;
}

export type SlotStatus = 'libre' | 'ocupado' | 'reservado' | 'mantenimiento' | 'discapacitado';

export interface ParkingOccupant {
  nombre: string;
  rut: string;
  patente: string;
  marca: string;
  modelo: string;
  color: string;
  entrada: string; // ISO or string time
}

export interface ParkingSlot {
  id: string; // e.g. "A-15"
  sector: 'A' | 'B' | 'C';
  numero: number;
  estado: SlotStatus;
  ocupante?: ParkingOccupant;
}

export interface ActivityLog {
  id: string;
  tipo: 'ticket_expirado' | 'entrada_detectada' | 'sensor_offline' | 'discapacitado_infraccion';
  titulo: string;
  detalle: string;
  haceMinutos: number;
  timestamp: string;
}

export type TicketType = 'problema' | 'consulta' | 'reporte';
export type TicketState = 'abierto' | 'en_curso' | 'cerrado';

export interface TicketReply {
  id: string;
  autor: string;
  contenido: string;
  fecha: string;
}

export interface SupportTicket {
  id: string;
  usuarioNombre: string;
  usuarioRut: string;
  tipo: TicketType;
  estado: TicketState;
  mensaje: string;
  haceTiempo: string;
  created_at: string;
  respuestas: TicketReply[];
}
