import React, { useState, useEffect } from 'react';
import { UserProfile, ParkingSlot, ActivityLog, SupportTicket } from './types';
import { DEMO_PROFILES, loadDataState, saveDataState } from './data';
import { LoginView } from './components/LoginView';
import { GuardDashboard } from './components/GuardDashboard';
import { DriverDashboard } from './components/DriverDashboard';
import { MapView } from './components/MapView';
import { TicketsView } from './components/TicketsView';

export default function App() {
  // Core authentication and role states
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState<string>('inicio');

  // Simulated database arrays
  const [slots, setSlots] = useState<ParkingSlot[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);

  // Tents & notification popup simulated state
  const [globalNotif, setGlobalNotif] = useState<string | null>(null);

  // Initialize data from localstorage or predefined seeds
  useEffect(() => {
    const { slots, logs, tickets } = loadDataState();
    setSlots(slots);
    setLogs(logs);
    setTickets(tickets);
  }, []);

  // Update states securely and persist to storage
  const handleUpdateDatabase = (
    newSlots: ParkingSlot[],
    newLogs: ActivityLog[],
    newTickets: SupportTicket[]
  ) => {
    setSlots(newSlots);
    setLogs(newLogs);
    setTickets(newTickets);
    saveDataState(newSlots, newLogs, newTickets);
  };

  // Helper trigger to show transient alerts
  const triggerNotification = (msg: string) => {
    setGlobalNotif(msg);
    setTimeout(() => setGlobalNotif(null), 4000);
  };

  // Automatic state progression to simulate active vehicles and updates
  useEffect(() => {
    const interval = setInterval(() => {
      if (!currentUser) return;
      
      // Randomly change a generic space's occupancy to make it "live"
      const randomIndex = Math.floor(Math.random() * slots.length);
      const slot = slots[randomIndex];
      if (slot && slot.id !== 'A-15' && slot.id !== 'B-12') { // protect key demonstration lots
        const newStatus = slot.estado === 'libre' ? 'ocupado' : 'libre';
        const updatedSlots = slots.map((s, idx) => {
          if (idx === randomIndex) {
            return {
              ...s,
              estado: newStatus,
              ocupante: newStatus === 'ocupado' ? {
                nombre: 'Felipe Alarcón (Docente)',
                rut: '14.930.291-K',
                patente: 'FP-RT-' + randomIndex,
                marca: 'Nissan',
                modelo: 'Centra',
                color: 'Plateado',
                entrada: new Date().toISOString()
              } : undefined
            };
          }
          return s;
        });

        const newLog: ActivityLog = {
          id: `log-auto-${Date.now()}`,
          tipo: newStatus === 'ocupado' ? 'entrada_detectada' : 'ticket_expirado',
          titulo: newStatus === 'ocupado' ? 'Entrada Detectada' : 'Vehículo Saliente',
          detalle: `Espacio ${slot.id} • ${newStatus === 'ocupado' ? 'Ocupado por Patente FP-RT-' + randomIndex : 'Disponible'}`,
          haceMinutos: 0,
          timestamp: new Date().toISOString()
        };

        // Notify user about random simulation event
        if (Math.random() > 0.85) {
          triggerNotification(`Sede Maipú: Espacio ${slot.id} se ha marcado como ${newStatus.toUpperCase()}`);
        }

        handleUpdateDatabase(updatedSlots, [newLog, ...logs.slice(0, 15)], tickets);
      }
    }, 15000); // simulation interval

    return () => clearInterval(interval);
  }, [slots, logs, tickets, currentUser]);

  // Handle Logout
  const handleLogout = () => {
    setCurrentUser(null);
    setActiveTab('inicio');
  };

  // Show login screen if not logged in
  if (!currentUser) {
    return (
      <LoginView 
        onLoginSuccess={(profile) => {
          setCurrentUser(profile);
          triggerNotification(`Sesión iniciada como ${profile.nombre} (${profile.role.toUpperCase()})`);
        }} 
      />
    );
  }

  // Active role variables
  const isConductor = currentUser.role === 'conductor';
  const isGuardia = currentUser.role === 'guardia';
  const isDirectivo = currentUser.role === 'directivo';

  // Global counts for indicators
  const totalSlots = slots.length;
  const occupiedCount = slots.filter(s => s.estado === 'ocupado').length;
  const freeCount = slots.filter(s => s.estado === 'libre' || s.estado === 'discapacitado').length;
  const occupiedPct = Math.round((occupiedCount / totalSlots) * 100);
  const reservadoCount = slots.filter(s => s.estado === 'reservado').length;
  const maintenanceCount = slots.filter(s => s.estado === 'mantenimiento').length;

  return (
    <div className="relative min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      
      {/* GLOBAL TRANSIENT ALERT OVERLAY */}
      {globalNotif && (
        <div className="fixed top-20 right-6 left-6 md:left-auto md:w-96 z-50 bg-slate-900 border border-slate-800 text-white p-4 rounded-xl shadow-xl flex items-center justify-between gap-3 animate-slide-in">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-amber-500">notifications_active</span>
            <p className="text-xs font-semibold leading-snug">{globalNotif}</p>
          </div>
          <button onClick={() => setGlobalNotif(null)} className="text-slate-400 hover:text-white cursor-pointer select-none">
            <span className="material-symbols-outlined text-sm">close</span>
          </button>
        </div>
      )}

      {/* TOP INSTITUTIONAL APP HEADER */}
      <header className="w-full sticky top-0 z-40 bg-white border-b border-slate-200 flex justify-between items-center px-6 py-3.5 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-[#004481] rounded-lg flex items-center justify-center shadow-sm">
            <span className="material-symbols-outlined text-white text-xl font-extrabold" style={{ fontVariationSettings: "'FILL' 1, 'wght' 600" }}>
              local_parking
            </span>
          </div>
          <div>
            <span className="font-hanken text-base font-black text-[#004481] tracking-tight block">Sede Maipú</span>
            <span className="text-[9px] -mt-0.5 block px-1.5 py-0.2 bg-[#e0eaff] border border-blue-200 text-[#004481] uppercase font-mono font-bold rounded w-max">
              Vista: {currentUser.role}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => triggerNotification('Notificación Sede Maipú: Conectividad estable de tótems en tiempo real.')}
            className="hover:bg-slate-100 rounded-full p-2 transition-colors relative active:scale-95 cursor-pointer"
          >
            <span className="material-symbols-outlined text-slate-500">notifications</span>
            <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-[#004481] rounded-full border border-white animate-pulse"></span>
          </button>

          {/* User profile portraits */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex flex-col items-end">
              <span className="font-sans text-xs font-semibold text-slate-800 leading-tight">
                {currentUser.nombre}
              </span>
              <span className="font-mono text-[9px] text-[#004481] font-bold">
                Duoc Sede Maipú
              </span>
            </div>
            
            <img 
              alt="Avatar" 
              className="w-10 h-10 rounded-full border border-slate-200 object-cover shadow-sm bg-slate-100"
              src={currentUser.avatar}
            />
          </div>
        </div>
      </header>

      {/* CENTRAL FRAME CONTENT OVERLAY */}
      <main className="flex-1 flex flex-col md:flex-row">
        
        {/* FLOATING SIDEBAR FOR DESKTOP VIEWS */}
        <aside className="hidden md:flex w-64 bg-white border border-slate-200/80 p-5 m-4 rounded-2xl flex-col justify-between shadow-[0_8px_30px_rgb(0,0,0,0.06)] h-[calc(100vh-120px)] sticky top-[88px]">
          <div className="space-y-4">
            <p className="text-[10px] uppercase font-mono font-bold text-slate-400 tracking-wider pl-1">Navegación del Sistema</p>
            
            <button 
              onClick={() => setActiveTab('inicio')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold uppercase transition-all duration-200 active:scale-[0.97] hover:translate-x-0.5 cursor-pointer ${activeTab === 'inicio' ? 'bg-[#004481] text-white shadow-lg shadow-[#004481]/15 scale-[1.01]' : 'text-slate-600 hover:bg-[#e0eaff]/45 hover:text-[#004481]'}`}
            >
              <span className="material-symbols-outlined text-lg" style={{ fontVariationSettings: activeTab === 'inicio' ? "'FILL' 1" : "'FILL' 0" }}>home</span>
              <span>Inicio / Escritorio</span>
            </button>

            <button 
              onClick={() => setActiveTab('mapa')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold uppercase transition-all duration-200 active:scale-[0.97] hover:translate-x-0.5 cursor-pointer ${activeTab === 'mapa' ? 'bg-[#004481] text-white shadow-lg shadow-[#004481]/15 scale-[1.01]' : 'text-slate-600 hover:bg-[#e0eaff]/45 hover:text-[#004481]'}`}
            >
              <span className="material-symbols-outlined text-lg" style={{ fontVariationSettings: activeTab === 'mapa' ? "'FILL' 1" : "'FILL' 0" }}>map</span>
              <span>Mapa de Ocupación</span>
            </button>

            <button 
              onClick={() => setActiveTab('tickets')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold uppercase transition-all duration-200 active:scale-[0.97] hover:translate-x-0.5 cursor-pointer ${activeTab === 'tickets' ? 'bg-[#004481] text-white shadow-lg shadow-[#004481]/15 scale-[1.01]' : 'text-slate-600 hover:bg-[#e0eaff]/45 hover:text-[#004481]'}`}
            >
              <span className="material-symbols-outlined text-lg" style={{ fontVariationSettings: activeTab === 'tickets' ? "'FILL' 1" : "'FILL' 0" }}>confirmation_number</span>
              <span>Tickets de Asistencia</span>
            </button>

            {isDirectivo && (
              <button 
                onClick={() => setActiveTab('director')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold uppercase transition-all duration-200 active:scale-[0.97] hover:translate-x-0.5 cursor-pointer ${activeTab === 'director' ? 'bg-[#004481] text-white shadow-lg shadow-[#004481]/15 scale-[1.01]' : 'text-slate-600 hover:bg-[#e0eaff]/45 hover:text-[#004481]'}`}
              >
                <span className="material-symbols-outlined text-lg" style={{ fontVariationSettings: activeTab === 'director' ? "'FILL' 1" : "'FILL' 0" }}>analytics</span>
                <span>Análisis Directivo</span>
              </button>
            )}
          </div>

          <div className="pt-6 border-t border-slate-200">
            <button 
              onClick={handleLogout}
              className="w-full bg-rose-50 hover:bg-rose-100 text-rose-700 py-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.97]"
            >
              <span className="material-symbols-outlined text-sm">logout</span>
              <span>Cerrar Sesión</span>
            </button>
          </div>
        </aside>

        {/* SCREEN OUTLET CONTROLLER */}
        <div className="flex-grow">
          {activeTab === 'inicio' && (
            <>
              {isConductor && <DriverDashboard slots={slots} onNavigate={setActiveTab} />}
              {isGuardia && (
                <GuardDashboard 
                  slots={slots} 
                  logs={logs} 
                  tickets={tickets} 
                  onNavigate={setActiveTab} 
                  onUpdateState={handleUpdateDatabase}
                  currentUser={currentUser}
                />
              )}
              {isDirectivo && (
                <div className="p-6 max-w-5xl mx-auto space-y-6">
                  {/* Directivo / Auditor Quick Stats */}
                  <div className="flex justify-between items-center border-b border-[#c4c6d0] pb-4">
                    <div>
                      <h2 className="font-hanken text-3xl font-extrabold text-[#004481]">Consola Directiva maqueta</h2>
                      <p className="text-stone-500 text-sm">Resumen global e indicadores de Sede Maipú</p>
                    </div>
                  </div>

                  {/* KPIs bar */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-sm flex flex-col justify-between">
                      <span className="text-[10px] text-stone-500 font-mono tracking-wider font-extrabold uppercase">Ocupación Total</span>
                      <div className="font-hanken text-primary text-4xl font-extrabold mt-1">{occupiedPct}%</div>
                      <div className="w-full bg-[#f6f3f2] h-1.5 rounded-full overflow-hidden mt-2">
                        <div className="bg-[#004481] h-full" style={{ width: `${occupiedPct}%` }}></div>
                      </div>
                    </div>
                    <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-sm">
                      <span className="text-[10px] text-stone-500 font-mono tracking-wider font-extrabold uppercase">Libres</span>
                      <div className="font-hanken text-green-600 text-4xl font-extrabold mt-1">{freeCount}</div>
                    </div>
                    <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-sm">
                      <span className="text-[10px] text-stone-500 font-mono tracking-wider font-extrabold uppercase">Reservados Docentes</span>
                      <div className="font-hanken text-amber-550 text-amber-500 text-4xl font-extrabold mt-1">{reservadoCount}</div>
                    </div>
                    <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-sm">
                      <span className="text-[10px] text-stone-500 font-mono tracking-wider font-extrabold uppercase">Fuera Servicio</span>
                      <div className="font-hanken text-[#EAB308] text-4xl font-extrabold mt-1">{maintenanceCount}</div>
                    </div>
                  </div>

                  {/* Audit Logs */}
                  <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-sm">
                    <h3 className="font-hanken font-extrabold text-stone-900 mb-4 flex items-center gap-1.5 uppercase tracking-wider text-xs">
                      <span className="material-symbols-outlined text-[#004481] text-base">receipt_long</span>
                      Bitácora de Auditoría en terreno
                    </h3>
                    <div className="divide-y divide-stone-100 max-h-96 overflow-y-auto">
                      {logs.map(log => (
                        <div key={log.id} className="py-3 flex justify-between items-center text-xs">
                          <div>
                            <span className="font-bold text-stone-800">{log.titulo}</span>
                            <p className="text-stone-500">{log.detalle}</p>
                          </div>
                          <span className="font-mono text-stone-400 font-medium">Hace {log.haceMinutos} mins</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </>
          )}

          {activeTab === 'mapa' && (
            <MapView 
              slots={slots} 
              logs={logs} 
              tickets={tickets} 
              onUpdateState={handleUpdateDatabase} 
            />
          )}

          {activeTab === 'tickets' && (
            <TicketsView 
              slots={slots} 
              logs={logs} 
              tickets={tickets} 
              onUpdateState={handleUpdateDatabase} 
              currentUser={currentUser}
            />
          )}

          {activeTab === 'director' && (
            <div className="p-6 max-w-5xl mx-auto space-y-6">
              {/* Directivo / Auditor Metrics */}
              <div className="flex justify-between items-center border-b border-[#c4c6d0] pb-4">
                <div>
                  <h2 className="font-hanken text-3xl font-extrabold text-[#004481]">Análisis Técnico Directivo</h2>
                  <p className="text-stone-500 text-sm">Reportes históricos del comportamiento de rotación</p>
                </div>
              </div>

              {/* Custom SVG Graphic trend metrics */}
              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4">
                <div className="flex justify-between items-center">
                  <span className="font-mono text-[11px] text-[#44474e] uppercase font-bold tracking-wider">
                    Curva de Ocupación diaria (Últimos 30 días)
                  </span>
                  <span className="text-xs bg-amber-100 text-amber-900 border border-amber-200 font-bold px-3 py-1 rounded-full animate-pulse">
                    MÁXIMO HISTÓRICO: 82.3%
                  </span>
                </div>

                <div className="w-full bg-[#f6f3f2] p-4 rounded-xl flex items-center justify-center">
                  {/* Beautiful customized SVG Trend graph mockup */}
                  <svg className="w-full h-48" viewBox="0 0 500 150">
                    <defs>
                      <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#004481" stopOpacity="0.4" />
                        <stop offset="100%" stopColor="#004481" stopOpacity="0.0" />
                      </linearGradient>
                    </defs>
                    
                    {/* Grid Lines */}
                    <line x1="10" y1="20" x2="490" y2="20" stroke="#E5E7EB" strokeWidth="1" strokeDasharray="3,3" />
                    <line x1="10" y1="60" x2="490" y2="60" stroke="#E5E7EB" strokeWidth="1" strokeDasharray="3,3" />
                    <line x1="10" y1="100" x2="490" y2="100" stroke="#E5E7EB" strokeWidth="1" strokeDasharray="3,3" />
                    <line x1="10" y1="130" x2="490" y2="130" stroke="#D1D5DB" strokeWidth="1.5" />

                    {/* Gradient Area under trend path */}
                    <path 
                      d="M 10 130 C 50 110, 80 50, 110 50 C 140 50, 170 90, 200 80 C 230 70, 260 30, 290 25 C 320 20, 350 40, 380 45 C 410 50, 440 100, 490 105 L 490 130 Z" 
                      fill="url(#chartGrad)" 
                    />

                    {/* Bold trend line */}
                    <path 
                      d="M 10 130 C 50 110, 80 50, 110 50 C 140 50, 170 90, 200 80 C 230 70, 260 30, 290 25 C 320 20, 350 40, 380 45 C 410 50, 440 100, 490 105" 
                      fill="none" 
                      stroke="#004481" 
                      strokeWidth="3.5" 
                    />

                    {/* Highlighted maximum point marker */}
                    <circle cx="290" cy="25" r="5" fill="#FFD700" stroke="#004481" strokeWidth="2.5" />
                    <text x="290" y="15" fill="#004481" fontSize="10" fontWeight="bold" textAnchor="middle">82% (Pico)</text>
                  </svg>
                </div>
              </div>

              {/* Rotación insights */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-stone-200">
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-[#004481] mb-3">Tasa de Rotación horaria</h4>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between items-center py-1">
                      <span className="font-semibold text-stone-600">08:00 - 10:00 (Fácil ingreso)</span>
                      <span className="bg-green-100 text-green-800 font-extrabold px-2 py-0.5 rounded">Baja</span>
                    </div>
                    <div className="flex justify-between items-center py-1">
                      <span className="font-semibold text-stone-600">11:00 - 14:00 (Pico Docente)</span>
                      <span className="bg-red-105 text-red-800 bg-red-100 font-extrabold px-2 py-0.5 rounded">Muy Alta</span>
                    </div>
                    <div className="flex justify-between items-center py-1">
                      <span className="font-semibold text-stone-600">14:00 - 17:00 (Rotación media)</span>
                      <span className="bg-blue-100 text-blue-800 font-extrabold px-2 py-0.5 rounded">Media</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-stone-200 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-[#004481] mb-1">Alertas Automáticas Activas</h4>
                    <p className="text-[11px] text-stone-500">Reglas configuradas de negocio de Sede Maipú</p>
                  </div>
                  
                  <div className="bg-amber-50 text-amber-900 border border-amber-200 rounded-lg p-3 text-xs flex items-center gap-2 mt-3 font-medium">
                    <span className="material-symbols-outlined text-stone-700">warning</span>
                    <span>Capacidad crítica registrada en Sector C con más de 1 hora al 95%.</span>
                  </div>
                </div>
              </div>

            </div>
          )}

          {activeTab === 'perfil' && (
            <div className="p-6 max-w-md mx-auto space-y-6">
              
              {/* Profile Card detail */}
              <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-md flex flex-col items-center p-6 text-center space-y-4">
                <img 
                  src={currentUser.avatar} 
                  alt="avatar" 
                  className="w-24 h-24 rounded-full border-4 border-[#004481]/10 object-cover shadow bg-[#f1edec]"
                />
                
                <div>
                  <h2 className="font-hanken text-2xl font-extrabold text-[#004481]">{currentUser.nombre}</h2>
                  <p className="text-stone-500 text-sm font-semibold capitalize bg-stone-100 py-0.5 px-3 rounded-full inline-block mt-1">
                    {currentUser.role} del sistema
                  </p>
                </div>

                <div className="w-full pt-4 border-t border-stone-100 text-left text-xs space-y-2 font-medium text-stone-600">
                  <div className="flex justify-between">
                    <span>RUT:</span>
                    <span className="font-mono font-bold text-stone-800">{currentUser.rut}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Correo Institucional:</span>
                    <span className="font-bold text-stone-800 text-right truncate max-w-[200px]">{currentUser.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sede Registrada:</span>
                    <span className="font-bold text-stone-850">Duoc UC Maipú</span>
                  </div>
                </div>

                <button 
                  onClick={handleLogout}
                  className="w-full bg-[#004481] hover:bg-[#003362] text-white py-3 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-transform"
                >
                  <span className="material-symbols-outlined text-sm">logout</span>
                  <span>Cerrar Sesión</span>
                </button>
              </div>

            </div>
          )}
        </div>

      </main>

      {/* FLOAT DEV CONTROLLER OVERLAY FOR INSTANT ROLE SWITCH - VERY HELPFUL FOR DEMOING ALL 3 SCREENSHOT MODES */}
      <div className="fixed bottom-20 left-4 z-40 bg-stone-900 border border-stone-800 p-3 rounded-xl shadow-2xl space-y-2 max-w-[260px] text-white">
        <p className="text-[10px] uppercase font-mono font-black text-amber-500 tracking-wider text-center">Cambio de Rol en Caliente:</p>
        <div className="grid grid-cols-3 gap-1">
          <button
            onClick={() => {
              setCurrentUser(DEMO_PROFILES.conductor);
              setActiveTab('inicio');
              triggerNotification('Consola: Rol cambiado a Conductor');
            }}
            className={`py-1.5 px-1 rounded text-[10px] font-bold text-center cursor-pointer transition-colors ${currentUser.role === 'conductor' ? 'bg-[#004481] text-white' : 'bg-stone-800 text-stone-300 hover:bg-stone-750'}`}
          >
            Conductor
          </button>
          <button
            onClick={() => {
              setCurrentUser(DEMO_PROFILES.guardia);
              setActiveTab('inicio');
              triggerNotification('Consola: Rol cambiado a Guardia');
            }}
            className={`py-1.5 px-1 rounded text-[10px] font-bold text-center cursor-pointer transition-colors ${currentUser.role === 'guardia' ? 'bg-[#004481] text-white' : 'bg-stone-800 text-stone-300 hover:bg-stone-750'}`}
          >
            Guardia
          </button>
          <button
            onClick={() => {
              setCurrentUser(DEMO_PROFILES.directivo);
              setActiveTab('inicio');
              triggerNotification('Consola: Rol cambiado a Directivo / Auditor');
            }}
            className={`py-1.5 px-1 rounded text-[10px] font-bold text-center cursor-pointer transition-colors ${currentUser.role === 'directivo' ? 'bg-[#004481] text-white' : 'bg-stone-800 text-stone-300 hover:bg-stone-750'}`}
          >
            Directivo
          </button>
        </div>
      </div>

      {/* FLOATING MOBILE BOTTOM NAVIGATION BAR */}
      <nav className="md:hidden fixed bottom-4 left-4 right-4 z-50 bg-white/95 backdrop-blur-md border border-slate-200 rounded-2xl flex justify-around items-center py-2.5 shadow-[0_10px_30px_rgba(0,0,0,0.125)]">
        <button 
          onClick={() => setActiveTab('inicio')}
          className={`flex flex-col items-center justify-center px-4 py-1.5 rounded-xl transition-all duration-300 active:scale-90 cursor-pointer select-none ${activeTab === 'inicio' ? 'text-[#004481] bg-[#e0eaff]/70 scale-105 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
        >
          <span className="material-symbols-outlined text-xl" style={{ fontVariationSettings: activeTab === 'inicio' ? "'FILL' 1" : "'FILL' 0" }}>home</span>
          <span className="text-[10px] font-bold mt-0.5 uppercase tracking-wider">Inicio</span>
        </button>
        
        <button 
          onClick={() => setActiveTab('mapa')}
          className={`flex flex-col items-center justify-center px-4 py-1.5 rounded-xl transition-all duration-300 active:scale-90 cursor-pointer select-none ${activeTab === 'mapa' ? 'text-[#004481] bg-[#e0eaff]/70 scale-105 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
        >
          <span className="material-symbols-outlined text-xl" style={{ fontVariationSettings: activeTab === 'mapa' ? "'FILL' 1" : "'FILL' 0" }}>map</span>
          <span className="text-[10px] font-bold mt-0.5 uppercase tracking-wider">Mapa</span>
        </button>

        <button 
          onClick={() => setActiveTab('tickets')}
          className={`flex flex-col items-center justify-center px-4 py-1.5 rounded-xl transition-all duration-300 active:scale-90 cursor-pointer select-none ${activeTab === 'tickets' ? 'text-[#004481] bg-[#e0eaff]/70 scale-105 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
        >
          <span className="material-symbols-outlined text-xl" style={{ fontVariationSettings: activeTab === 'tickets' ? "'FILL' 1" : "'FILL' 0" }}>confirmation_number</span>
          <span className="text-[10px] font-bold mt-0.5 uppercase tracking-wider">Tickets</span>
        </button>

        <button 
          onClick={() => setActiveTab('perfil')}
          className={`flex flex-col items-center justify-center px-4 py-1.5 rounded-xl transition-all duration-300 active:scale-90 cursor-pointer select-none ${activeTab === 'perfil' ? 'text-[#004481] bg-[#e0eaff]/70 scale-105 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
        >
          <span className="material-symbols-outlined text-xl" style={{ fontVariationSettings: activeTab === 'perfil' ? "'FILL' 1" : "'FILL' 0" }}>person</span>
          <span className="text-[10px] font-bold mt-0.5 uppercase tracking-wider">Perfil</span>
        </button>
      </nav>

    </div>
  );
}
