import { ParkingSlot, ActivityLog, SupportTicket, UserProfile } from './types';

// Predefined Demo Profiles
export const DEMO_PROFILES: Record<string, UserProfile> = {
  guardia: {
    rut: '12.345.678-9',
    nombre: 'Juan Pablo Martínez',
    email: 'j.martinez@duoc.cl',
    role: 'guardia',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBWpLLxKp0lhnFbZpgqG3NBLJQpCZaDY8aBbO0jUiaI_JcqIh5R_Xpc-hEfdQvLvmkBWTkq-1snL-Ui4J_-fXzw9m7F21SXLds96cXy-X-1MxJKM0qwmmEynwHsMDB2GpQaqVwFZzSc0-dtaY6UeIQJLRPtp6U4YrKmeovzVMmVZnO_bAnkQNxZgwvMWyANESJuweZ5ZSoTpA4pDhzTUrNFuD3HZAFFDZJZDGCyGYBOkMfXDqMh3JKpL4KST36YGsKzfXsxTpWshIk'
  },
  conductor: {
    rut: '18.987.654-3',
    nombre: 'Daniel Reyes',
    email: 'daniel.reyes.duoc@gmail.com',
    role: 'conductor',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCji0yx5NnkM5z_m_gRKzSV0usSkUKw21cCRiReNEK0FhWlJhMJUMfNmFUNY1ttoiwAymuBws07QD-ndW0Oy1ORc9_O7nSZebvI-EVUjmGxwLO54wzy7boib4gJPqrA6qBnbex9j046bVNuUVtzjAJvC-7LI2VilBv9F5UJ7Wte_42UuDqdXU0cUtRqGeaWkdcbeBKYBRQJ5j6mOayV_VnaSkwAviqJiLIZ1EZXbSC_ZBZ45gMvaRSymHR3-ZZHUgKjzC3D_0V_km4'
  },
  directivo: {
    rut: '15.432.109-8',
    nombre: 'Director Héctor Tapia',
    email: 'h.tapia@duoc.cl',
    role: 'directivo',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBWpLLxKp0lhnFbZpgqG3NBLJQpCZaDY8aBbO0jUiaI_JcqIh5R_Xpc-hEfdQvLvmkBWTkq-1snL-Ui4J_-fXzw9m7F21SXLds96cXy-X-1MxJKM0qwmmEynwHsMDB2GpQaqVwFZzSc0-dtaY6UeIQJLRPtp6U4YrKmeovzVMmVZnO_bAnkQNxZgwvMWyANESJuweZ5ZSoTpA4pDhzTUrNFuD3HZAFFDZJZDGCyGYBOkMfXDqMh3JKpL4KST36YGsKzfXsxTpWshIk'
  }
};

// Seeding 110 Parking Spaces
const generateInitialSlots = (): ParkingSlot[] => {
  const slots: ParkingSlot[] = [];
  
  // Total spaces = 110, distributed among sectors to align perfectly with visual layout:
  // Sector A (Rows A, B, C): 18 + 12 + 12 = 42 slots (A-01 to A-42)
  // Sector B (Rows D, E, F + Column L): 10 + 10 + 10 + 12 = 42 slots (B-01 to B-42)
  // Sector C (Columns R1, R2): 13 + 13 = 26 slots (C-01 to C-26)
  const distribution = [
    { sector: 'A' as const, count: 42 },
    { sector: 'B' as const, count: 42 },
    { sector: 'C' as const, count: 26 }
  ];

  let globalIndex = 0;
  for (const group of distribution) {
    for (let num = 1; num <= group.count; num++) {
      globalIndex++;
      const sector = group.sector;
      const id = `${sector}-${String(num).padStart(2, '0')}`;
      
      let estado: ParkingSlot['estado'] = 'libre';
      let ocupante: ParkingSlot['ocupante'] = undefined;
      
      // Seed specific PMR/Disability slots:
      const isDisability = (sector === 'A' && (num === 4 || num === 20 || num === 30)) ||
                           (sector === 'B' && (num === 10 || num === 25)) ||
                           (sector === 'C' && num === 14);
      if (isDisability) {
        estado = 'discapacitado';
      }

      // Predefined states for main demo slots (otherwise generate deterministic random states)
      if (sector === 'A' && num === 15) {
        estado = 'libre';
      } else if (sector === 'B' && num === 12) {
        estado = 'ocupado';
        ocupante = {
          nombre: 'Pedro González',
          rut: '16.543.120-9',
          patente: 'FR-PT-99',
          marca: 'Ford',
          modelo: 'Raptor',
          color: 'Negro',
          entrada: new Date(Date.now() - 3.5 * 3600000).toISOString()
        };
      } else {
        const rand = Math.sin(globalIndex) * 0.5 + 0.5; // deterministic randomness
        if (rand < 0.45) {
          estado = 'libre';
        } else if (rand < 0.75) {
          estado = 'ocupado';
          ocupante = {
            nombre: ['Martín Sanhueza', 'Carla Torres', 'Jorge Valdivia', 'Ana María Rojas', 'David Cooper', 'Felipe Castro', 'Sofía Aravena'][globalIndex % 7],
            rut: `15.${340 + globalIndex}.678-K`,
            patente: ['KX-RT-88', 'LP-ZZ-12', 'GG-99-AA', 'BJ-12-CC', 'HH-55-KK', 'KJ-990-LP', 'BB-CC-11'][globalIndex % 7],
            marca: ['Ford', 'Chevrolet', 'Suzuki', 'Toyota', 'Nissan', 'Hyundai', 'Mazda'][globalIndex % 7],
            modelo: ['Raptor', 'Sail', 'Swift', 'Yaris', 'Versa', 'Accent', '3'][globalIndex % 7],
            color: ['Negro', 'Blanco', 'Rojo', 'Gris', 'Azul', 'Plateado', 'Grafito'][globalIndex % 7],
            entrada: new Date(Date.now() - (globalIndex * 12 * 60000)).toISOString()
          };
        } else if (rand < 0.88) {
          estado = 'reservado';
          ocupante = {
            nombre: 'Docente Reservado',
            rut: '14.000.000-0',
            patente: 'RES-00-' + num,
            marca: 'Toyota',
            modelo: 'Corolla',
            color: 'Gris',
            entrada: new Date().toISOString()
          };
        } else if (rand < 0.94) {
          estado = 'mantenimiento';
        } else {
          estado = 'ocupado';
          ocupante = {
            nombre: 'Juan Carlos Ruiz',
            rut: '14.120.340-5',
            patente: 'AA-452-BB',
            marca: 'Toyota',
            modelo: 'Yaris',
            color: 'Negro',
            entrada: new Date(Date.now() - 25 * 60000).toISOString()
          };
        }
      }

      slots.push({
        id,
        sector,
        numero: num,
        estado,
        ocupante
      });
    }
  }

  // Enforce specific setup for A-15: "Your Space", "Lugar Verificado"
  const a15 = slots.find(s => s.sector === 'A' && s.numero === 15);
  if (a15) {
    a15.estado = 'libre';
    a15.ocupante = {
      nombre: 'Daniel Reyes',
      rut: '18.987.654-3',
      patente: 'AA-452-BB',
      marca: 'Mercedes Benz',
      modelo: 'Colección',
      color: 'Gris Oscuro',
      entrada: new Date(Date.now() - 2 * 3600000).toISOString() // 2 hours ago
    };
  }

  return slots;
};

// Seeding standard activity logs
const INITIAL_LOGS: ActivityLog[] = [
  {
    id: 'l-1',
    tipo: 'ticket_expirado',
    titulo: 'Ticket Expirado',
    detalle: 'Espacio B-12 • Ford Raptor Negro',
    haceMinutos: 2,
    timestamp: new Date(Date.now() - 2 * 60000).toISOString()
  },
  {
    id: 'l-2',
    tipo: 'entrada_detectada',
    titulo: 'Entrada Detectada',
    detalle: 'Espacio A-05 • Registro QR 9982',
    haceMinutos: 14,
    timestamp: new Date(Date.now() - 14 * 60000).toISOString()
  },
  {
    id: 'l-3',
    tipo: 'sensor_offline',
    titulo: 'Sensor Fuera de Línea',
    detalle: 'Zona C • Revisión necesaria',
    haceMinutos: 45,
    timestamp: new Date(Date.now() - 45 * 60000).toISOString()
  }
];

// Seeding Support Tickets (screen 4)
const INITIAL_TICKETS: SupportTicket[] = [
  {
    id: 't-1',
    usuarioNombre: 'Juan Pérez',
    usuarioRut: '12.345.678-9',
    tipo: 'problema',
    estado: 'abierto',
    mensaje: 'No puedo validar mi QR en el sector A. La pantalla no responde al escaneo.',
    haceTiempo: 'Hace 2 min',
    created_at: new Date(Date.now() - 120000).toISOString(),
    respuestas: []
  },
  {
    id: 't-2',
    usuarioNombre: 'María Soto',
    usuarioRut: '18.987.654-3',
    tipo: 'consulta',
    estado: 'abierto',
    mensaje: 'Solicito información sobre el sector de discapacitados, ¿hay cupos disponibles en el piso 2?',
    haceTiempo: 'Hace 15 min',
    created_at: new Date(Date.now() - 900000).toISOString(),
    respuestas: []
  },
  {
    id: 't-3',
    usuarioNombre: 'Carlos Ruiz',
    usuarioRut: '15.432.109-8',
    tipo: 'reporte',
    estado: 'abierto',
    mensaje: 'Vehículo mal estacionado bloqueando mi salida. Patente BB-CC-11.',
    haceTiempo: 'Hace 1 h',
    created_at: new Date(Date.now() - 3600000).toISOString(),
    respuestas: []
  }
];

// LocalStorage State Keys
const STORAGE_KEY_SLOTS = 'codec_maipu_slots';
const STORAGE_KEY_LOGS = 'codec_maipu_logs';
const STORAGE_KEY_TICKETS = 'codec_maipu_tickets';

export const loadDataState = () => {
  let slots = generateInitialSlots();
  let logs = INITIAL_LOGS;
  let tickets = INITIAL_TICKETS;

  try {
    const savedSlots = localStorage.getItem(STORAGE_KEY_SLOTS);
    if (savedSlots) slots = JSON.parse(savedSlots);
    
    const savedLogs = localStorage.getItem(STORAGE_KEY_LOGS);
    if (savedLogs) logs = JSON.parse(savedLogs);
    
    const savedTickets = localStorage.getItem(STORAGE_KEY_TICKETS);
    if (savedTickets) tickets = JSON.parse(savedTickets);
  } catch (e) {
    console.error('Error reading localStorage seed:', e);
  }

  return { slots, logs, tickets };
};

export const saveDataState = (slots: ParkingSlot[], logs: ActivityLog[], tickets: SupportTicket[]) => {
  try {
    localStorage.setItem(STORAGE_KEY_SLOTS, JSON.stringify(slots));
    localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(logs));
    localStorage.setItem(STORAGE_KEY_TICKETS, JSON.stringify(tickets));
  } catch (e) {
    console.error('Error writing localStorage state:', e);
  }
};

// Helper simulation of AI chatbot/Guard responses
export const generateSupportReply = (ticket: SupportTicket): string => {
  const lowerMsg = ticket.mensaje.toLowerCase();
  
  if (lowerMsg.includes('qr') || lowerMsg.includes('escaneo') || lowerMsg.includes('escanear')) {
    return `Hola ${ticket.usuarioNombre}, entiendo su problema con el código QR. He enviado una señal de restablecimiento al Tótem de Escaneo en el Sector A. Por favor intente nuevamente, o muestre su código en la caseta de guardia 082 para validación manual.`;
  }
  
  if (lowerMsg.includes('discapacitados') || lowerMsg.includes('cupos') || lowerMsg.includes('pmr')) {
    return `Estimada ${ticket.usuarioNombre}, actualmente disponemos de 3 cupos PMR (Discapacitados) disponibles en el Sector A, y 1 cupo disponible en el Sector B. Todos equipados con sensores activos.`;
  }

  if (lowerMsg.includes('bloqueando') || lowerMsg.includes('patente') || lowerMsg.includes('mal estacionado')) {
    return `Atendido ${ticket.usuarioNombre}. El equipo de patrullas se dirige al lugar con grúa interna de Duoc UC para inspeccionar la patente indicada y despejar la vía de inmediato.`;
  }

  return `Hola ${ticket.usuarioNombre}, recibimos tu reporte. Un guardia ha sido asignado a tu caso y te brindará asistencia en terreno a la brevedad. Gracias por informar.`;
};
